# Service image checklist

Upload one realistic photograph per row to Supabase Storage bucket `service-images` as `<slug>.jpg` (square, ~800x800, light/neutral background, consistent treatment), then set `image_url` in the admin dashboard (or run the SQL at the bottom).


## Electrical

- `fan-installation.jpg` — Fan Installation
- `fan-repair.jpg` — Fan Repair
- `light-installation.jpg` — Light Installation
- `led-installation.jpg` — LED Installation
- `switch-socket-repair.jpg` — Switch & Socket Repair
- `wiring-rewiring.jpg` — Wiring & Rewiring
- `mcb-installation.jpg` — MCB Installation
- `electrical-fault-repair.jpg` — Electrical Fault Repair
- `inverter-installation.jpg` — Inverter Installation
- `doorbell-installation.jpg` — Doorbell Installation

## Plumbing

- `tap-repair.jpg` — Tap Repair
- `tap-installation.jpg` — Tap Installation
- `wash-basin-installation.jpg` — Wash Basin Installation
- `wash-basin-blockage.jpg` — Wash Basin Blockage
- `bathroom-plumbing.jpg` — Bathroom Plumbing
- `kitchen-plumbing.jpg` — Kitchen Plumbing
- `pipe-leakage-repair.jpg` — Pipe Leakage Repair
- `toilet-repair.jpg` — Toilet Repair
- `flush-tank-repair.jpg` — Flush Tank Repair
- `water-motor-installation.jpg` — Water Motor Installation
- `water-tank-cleaning.jpg` — Water Tank Cleaning

## Appliances

- `ac-installation.jpg` — AC Installation
- `ac-general-service.jpg` — AC General Service
- `ac-foam-jet-cleaning.jpg` — AC Foam Jet Cleaning
- `ac-gas-refilling.jpg` — AC Gas Refilling
- `ac-repair.jpg` — AC Repair
- `washing-machine-repair.jpg` — Washing Machine Repair
- `washing-machine-service.jpg` — Washing Machine Service
- `refrigerator-repair.jpg` — Refrigerator Repair
- `refrigerator-general-service.jpg` — Refrigerator General Service
- `microwave-oven-repair.jpg` — Microwave Oven Repair
- `geyser-installation-repair.jpg` — Geyser Installation & Repair
- `water-purifier-service.jpg` — Water Purifier Service
- `television-repair.jpg` — Television Repair
- `chimney-repair.jpg` — Chimney Repair
- `stove-service-repair.jpg` — Stove Service & Repair
- `laptop-repair.jpg` — Laptop Repair

## Home Cleaning

- `full-home-deep-cleaning.jpg` — Full Home Deep Cleaning
- `bathroom-deep-cleaning.jpg` — Bathroom Deep Cleaning
- `kitchen-deep-cleaning.jpg` — Kitchen Deep Cleaning
- `sofa-cleaning.jpg` — Sofa Cleaning
- `carpet-cleaning.jpg` — Carpet Cleaning
- `mattress-cleaning.jpg` — Mattress Cleaning
- `window-cleaning.jpg` — Window Cleaning
- `floor-cleaning.jpg` — Floor Cleaning
- `move-in-cleaning.jpg` — Move-In Cleaning
- `move-out-cleaning.jpg` — Move-Out Cleaning

## Packers & Movers

- `local-home-shifting.jpg` — Local Home Shifting
- `intercity-home-shifting.jpg` — Intercity Home Shifting
- `office-relocation.jpg` — Office Relocation
- `furniture-shifting.jpg` — Furniture Shifting
- `packing-unpacking.jpg` — Packing & Unpacking
- `loading-unloading.jpg` — Loading & Unloading
- `vehicle-transportation.jpg` — Vehicle Transportation
- `single-item-shifting.jpg` — Single Item Shifting

```sql
update services set image_url = '<SUPABASE_URL>/storage/v1/object/public/service-images/' || slug || '.jpg' where image_url is null;
```
