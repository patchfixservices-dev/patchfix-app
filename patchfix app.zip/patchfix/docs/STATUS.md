# Status (Android-only scope)

Legend: ✅ written · ⚠️ written, needs your configuration · ⛔ not built

## Mobile (Android)
- ✅ Splash, 3-slide onboarding (skippable), phone OTP login, verify, register, profile edit, logout
- ✅ Home (location, search, banner, categories, popular, why PatchFix, published reviews only)
- ✅ Image-led category cards and grouped service grids matching the reference screenshots; per-service detail screen
- ✅ Search (name/description/keywords), saved addresses with map pin, device geocoder search, "use my location", PIN serviceability check
- ✅ 5-step booking: options → address → date/slot (live availability) → details + up to 3 photos → review/coupon/payment
- ✅ Booking list (upcoming/past/cancelled), detail, status timeline, cancellation within policy, notification list, help/support ticket
- ⚠️ Online payment (Razorpay) — needs keys, deployed functions, EAS APK (not Expo Go)
- ⚠️ Push — needs FCM credentials + DB webhook
- ⚠️ Phone OTP — needs SMS provider in Supabase
- ⚠️ Terms/Privacy links point to placeholder URLs in `profile.tsx` — replace with your real pages
- ⛔ Rescheduling (policy/UI not built; cancel + rebook for now), review submission screen (table + RLS exist), payment-retry button for failed online payments, offline banner, Places autocomplete

## Backend
- ✅ 25-table schema, RLS on every table, audit triggers, status-history trigger, storage buckets + policies
- ✅ `create_booking` RPC: server-side pricing, PIN check, slot capacity under advisory lock, idempotency key, coupons
- ✅ Razorpay order + webhook (signature check, idempotent events, amount check), cash-collected RPC (staff only)
- ⚠️ Seed prices are demo estimates; PIN codes are a starter list — verify in admin
- ⛔ Technician app (Phase 2). Backend foundation exists: professionals, assignments, RLS for assigned jobs
- ⛔ Email/WhatsApp notifications, automated reminders (needs a scheduled function)

## Admin (responsive web)
- ✅ Login with staff check, overview (date filter, separate gross/collected/pending/refunded), bookings (filters, status, assign, cash), services (edit, image upload, active), cities + PIN codes, payments + CSV, coupons, reviews moderation, customers (suspend/restore)
- ⛔ Category CRUD, variants/add-ons editor, professionals management UI (use SQL/Supabase table editor for now)

## Not yet verified (nothing has been executed)
TypeScript/build, Expo SDK version alignment, RLS tests per role, Razorpay test flow, APK install on devices.
