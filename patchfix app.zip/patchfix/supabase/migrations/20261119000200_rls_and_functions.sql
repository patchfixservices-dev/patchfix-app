-- Row Level Security + server-side booking logic.
alter table profiles enable row level security;
alter table user_roles enable row level security;
alter table cities enable row level security;
alter table service_areas enable row level security;
alter table service_categories enable row level security;
alter table services enable row level security;
alter table service_variants enable row level security;
alter table service_images enable row level security;
alter table addresses enable row level security;
alter table professionals enable row level security;
alter table professional_services enable row level security;
alter table professional_availability enable row level security;
alter table bookings enable row level security;
alter table booking_items enable row level security;
alter table booking_status_history enable row level security;
alter table booking_assignments enable row level security;
alter table payments enable row level security;
alter table payment_events enable row level security;
alter table coupons enable row level security;
alter table coupon_redemptions enable row level security;
alter table reviews enable row level security;
alter table notifications enable row level security;
alter table app_settings enable row level security;
alter table support_requests enable row level security;
alter table audit_logs enable row level security;

-- helper to (re)create policies idempotently
create or replace function _pol(tbl text, name text, cmd text, using_expr text, check_expr text default null)
returns void language plpgsql as $$
begin
  execute format('drop policy if exists %I on %I', name, tbl);
  execute format('create policy %I on %I for %s %s %s', name, tbl, cmd,
    case when using_expr is not null then 'using ('||using_expr||')' else '' end,
    case when check_expr is not null then 'with check ('||check_expr||')' else '' end);
end $$;

-- public catalog (read active rows); staff manage
do $$ declare t text; begin
  foreach t in array array['cities','service_areas','service_categories','services','service_variants','service_images'] loop
    perform _pol(t, t||'_read', 'select', 'true');
    perform _pol(t, t||'_staff_write', 'all', 'is_staff()', 'is_staff()');
  end loop;
end $$;
select _pol('app_settings','settings_read','select','true');
select _pol('app_settings','settings_staff_write','all','is_staff()','is_staff()');

-- profiles
select _pol('profiles','profiles_self_read','select','id = auth.uid() or is_staff()');
select _pol('profiles','profiles_self_update','update','id = auth.uid()','id = auth.uid()');
select _pol('user_roles','roles_self_read','select','user_id = auth.uid() or is_staff()');
select _pol('user_roles','roles_admin_write','all','has_role(''admin'')','has_role(''admin'')');

-- addresses
select _pol('addresses','addr_owner','all','user_id = auth.uid()','user_id = auth.uid()');
select _pol('addresses','addr_staff_read','select','is_staff()');

-- bookings: customers read own; professionals read assigned; staff all. Customers cannot write directly (use RPCs).
select _pol('bookings','bookings_read','select',
  'user_id = auth.uid() or is_staff() or exists (select 1 from booking_assignments a join professionals p on p.id=a.professional_id where a.booking_id = bookings.id and p.user_id = auth.uid())');
select _pol('bookings','bookings_staff_update','update','is_staff()','is_staff()');
select _pol('booking_items','items_read','select','exists (select 1 from bookings b where b.id = booking_id)');
select _pol('booking_status_history','hist_read','select','exists (select 1 from bookings b where b.id = booking_id)');
select _pol('booking_assignments','assign_read','select','is_staff() or exists (select 1 from professionals p where p.id = professional_id and p.user_id = auth.uid()) or exists (select 1 from bookings b where b.id = booking_id and b.user_id = auth.uid())');
select _pol('booking_assignments','assign_staff_write','all','is_staff()','is_staff()');
select _pol('professionals','pros_staff','all','is_staff()','is_staff()');
select _pol('professionals','pros_self_read','select','user_id = auth.uid()');
select _pol('professional_services','pserv_staff','all','is_staff()','is_staff()');
select _pol('professional_availability','pavail_staff','all','is_staff()','is_staff()');

-- payments: customers read own; only staff/service role write
select _pol('payments','payments_read','select','is_staff() or exists (select 1 from bookings b where b.id = booking_id and b.user_id = auth.uid())');
select _pol('payments','payments_staff_update','update','is_staff()','is_staff()');
select _pol('payment_events','pevents_staff','select','is_staff()');

-- coupons: staff manage; customers validate through RPC only
select _pol('coupons','coupons_staff','all','is_staff()','is_staff()');
select _pol('coupon_redemptions','redeem_staff_read','select','is_staff() or user_id = auth.uid()');

-- reviews: customers write own for completed bookings; public reads published
select _pol('reviews','reviews_public_read','select','is_published or user_id = auth.uid() or is_staff()');
select _pol('reviews','reviews_insert','insert',null,
  'user_id = auth.uid() and exists (select 1 from bookings b where b.id = booking_id and b.user_id = auth.uid() and b.status = ''completed'')');
select _pol('reviews','reviews_staff_update','update','is_staff()','is_staff()');

select _pol('notifications','notif_owner_read','select','user_id = auth.uid()');
select _pol('notifications','notif_owner_update','update','user_id = auth.uid()','user_id = auth.uid()');
select _pol('support_requests','support_owner','all','user_id = auth.uid() or is_staff()','user_id = auth.uid()');
select _pol('audit_logs','audit_staff_read','select','is_staff()');

-- Prevent clients from changing sensitive profile columns (push token / name allowed)
revoke update on profiles from authenticated;
grant update (full_name, email, expo_push_token, notifications_enabled) on profiles to authenticated;

-- ---------- serviceability ----------
create or replace function check_serviceable(p_pincode text)
returns table (city_id uuid, city_name text) language sql stable security definer set search_path = public as $$
  select c.id, c.name from service_areas a join cities c on c.id = a.city_id
  where a.pincode = p_pincode and a.is_active and c.is_active limit 1;
$$;

-- ---------- slots ----------
create or replace function available_slots(p_city uuid, p_date date)
returns table (slot text, remaining int) language plpgsql stable security definer set search_path = public as $$
declare slots jsonb; cap int;
begin
  select value into slots from app_settings where key = 'booking_slots';
  select coalesce((value)::int, 5) into cap from app_settings where key = 'slot_capacity';
  cap := coalesce(cap, 5);
  return query
  select s::text, greatest(cap - (select count(*)::int from bookings b
      where b.city_id = p_city and b.scheduled_date = p_date and b.slot = s::text and b.status <> 'cancelled'), 0)
  from jsonb_array_elements_text(coalesce(slots, '["09:00-11:00","11:00-13:00","13:00-15:00","15:00-17:00","17:00-19:00"]'::jsonb)) s;
end $$;

-- ---------- coupon preview ----------
create or replace function preview_coupon(p_code text, p_subtotal numeric)
returns numeric language plpgsql stable security definer set search_path = public as $$
declare c coupons; d numeric;
begin
  select * into c from coupons where upper(code) = upper(p_code) and is_active
    and (expires_at is null or expires_at > now()) and (usage_limit is null or used_count < usage_limit);
  if not found or p_subtotal < c.min_amount then return 0; end if;
  d := case c.discount_type when 'percent' then p_subtotal * c.discount_value / 100 else c.discount_value end;
  if c.max_discount is not null then d := least(d, c.max_discount); end if;
  return round(least(d, p_subtotal), 2);
end $$;

-- ---------- create booking (authoritative price + availability) ----------
create or replace function create_booking(
  p_service_id uuid, p_variant_ids uuid[], p_quantity int, p_address_id uuid,
  p_date date, p_slot text, p_name text, p_phone text, p_notes text,
  p_payment_method payment_method, p_coupon text, p_idempotency_key text, p_photo_paths text[] default '{}'
) returns bookings language plpgsql security definer set search_path = public as $$
declare
  uid uuid := auth.uid(); svc services; addr addresses; v_city uuid; adj numeric; unit numeric;
  sub numeric := 0; fee numeric := 0; tx numeric := 0; disc numeric := 0; cap int; used int;
  b bookings; var service_variants; fee_flat numeric; tax_pct numeric; cpn coupons;
begin
  if uid is null then raise exception 'not_authenticated'; end if;
  if p_quantity < 1 or p_quantity > 20 then raise exception 'invalid_quantity'; end if;
  if p_date < (now() at time zone 'Asia/Kolkata')::date then raise exception 'date_in_past'; end if;
  if length(trim(coalesce(p_name,''))) < 2 or p_phone !~ '^\+?[0-9]{10,13}$' then raise exception 'invalid_contact'; end if;

  -- idempotency: same key returns the existing booking
  select * into b from bookings where user_id = uid and idempotency_key = p_idempotency_key;
  if found then return b; end if;

  select * into svc from services where id = p_service_id and is_active;
  if not found then raise exception 'service_unavailable'; end if;
  select * into addr from addresses where id = p_address_id and user_id = uid;
  if not found then raise exception 'address_not_found'; end if;
  select city_id into v_city from check_serviceable(addr.pincode);
  if v_city is null then raise exception 'area_not_serviceable'; end if;
  if not exists (select 1 from available_slots(v_city, p_date) where slot = p_slot) then raise exception 'invalid_slot'; end if;

  -- serialize concurrent bookings for the same city/date/slot
  perform pg_advisory_xact_lock(hashtextextended(v_city::text || p_date::text || p_slot, 0));
  select coalesce((select (value)::int from app_settings where key='slot_capacity'),5) into cap;
  select count(*) into used from bookings where city_id = v_city and scheduled_date = p_date and slot = p_slot and status <> 'cancelled';
  if used >= cap then raise exception 'slot_full'; end if;

  select price_adjustment_pct into adj from cities where id = v_city;
  unit := round(svc.base_price * (1 + coalesce(adj,0)/100), 2);
  sub := unit * p_quantity;
  for var in select * from service_variants where id = any(coalesce(p_variant_ids,'{}')) and service_id = svc.id and is_active loop
    sub := sub + round(var.price * (1 + coalesce(adj,0)/100), 2);
  end loop;

  select coalesce((value)::numeric,0) into fee_flat from app_settings where key = 'platform_fee';
  select coalesce((value)::numeric,0) into tax_pct from app_settings where key = 'tax_percent';
  fee := coalesce(fee_flat,0);
  if p_coupon is not null and length(p_coupon) > 0 then disc := preview_coupon(p_coupon, sub); end if;
  tx := round((sub + fee - disc) * coalesce(tax_pct,0) / 100, 2);

  insert into bookings (user_id, address_id, city_id, scheduled_date, slot, customer_name, customer_phone, notes, photo_paths,
      subtotal, fees, tax, discount, total, is_estimate, coupon_code, payment_method, payment_status, idempotency_key)
  values (uid, addr.id, v_city, p_date, p_slot, trim(p_name), p_phone, p_notes, coalesce(p_photo_paths,'{}'),
      sub, fee, tx, disc, sub + fee - disc + tx, svc.price_is_estimate or svc.is_quote_only,
      nullif(p_coupon,''), p_payment_method,
      case p_payment_method when 'cash' then 'cash_pending'::payment_status else 'pending'::payment_status end, p_idempotency_key)
  returning * into b;

  insert into booking_items(booking_id, service_id, name, unit_price, quantity) values (b.id, svc.id, svc.name, unit, p_quantity);
  insert into booking_items(booking_id, service_id, variant_id, name, unit_price, quantity)
    select b.id, svc.id, v.id, v.name, v.price, 1 from service_variants v where v.id = any(coalesce(p_variant_ids,'{}')) and v.service_id = svc.id and v.is_active;
  insert into payments(booking_id, method, status, amount) values (b.id, p_payment_method, b.payment_status, b.total);
  if disc > 0 then
    select * into cpn from coupons where upper(code) = upper(p_coupon);
    insert into coupon_redemptions(coupon_id, user_id, booking_id) values (cpn.id, uid, b.id);
    update coupons set used_count = used_count + 1 where id = cpn.id;
  end if;
  insert into notifications(user_id, title, body, data)
    values (uid, 'Booking received', 'Your booking ' || b.reference || ' is received.', jsonb_build_object('booking_id', b.id));
  return b;
end $$;
grant execute on function create_booking to authenticated;
grant execute on function check_serviceable, available_slots, preview_coupon to authenticated, anon;

-- ---------- customer cancellation (policy: configurable hours before slot) ----------
create or replace function cancel_booking(p_booking_id uuid, p_reason text default null)
returns bookings language plpgsql security definer set search_path = public as $$
declare b bookings; hrs int; start_ts timestamptz;
begin
  select * into b from bookings where id = p_booking_id and user_id = auth.uid();
  if not found then raise exception 'booking_not_found'; end if;
  if b.status in ('completed','cancelled','in_progress') then raise exception 'cannot_cancel'; end if;
  select coalesce((value)::int, 4) into hrs from app_settings where key = 'cancellation_cutoff_hours';
  start_ts := ((b.scheduled_date::text || ' ' || split_part(b.slot,'-',1))::timestamp) at time zone 'Asia/Kolkata';
  if start_ts - now() < make_interval(hours => coalesce(hrs,4)) then raise exception 'cancellation_window_closed'; end if;
  update bookings set status = 'cancelled' where id = b.id returning * into b;
  update booking_status_history set note = p_reason where id = (select id from booking_status_history where booking_id = b.id order by created_at desc limit 1);
  return b;
end $$;
grant execute on function cancel_booking to authenticated;

-- ---------- staff: mark cash collected ----------
create or replace function mark_cash_collected(p_booking_id uuid) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_staff() then raise exception 'forbidden'; end if;
  update payments set status='cash_collected', collected_by=auth.uid(), collected_at=now()
    where booking_id = p_booking_id and method='cash' and status='cash_pending';
  update bookings set payment_status='cash_collected' where id = p_booking_id and payment_method='cash';
end $$;
grant execute on function mark_cash_collected to authenticated;

-- ---------- storage ----------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
  ('service-images','service-images', true, 2097152, array['image/jpeg','image/png','image/webp']),
  ('booking-photos','booking-photos', false, 5242880, array['image/jpeg','image/png','image/webp'])
on conflict (id) do update set file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "service images public read" on storage.objects;
create policy "service images public read" on storage.objects for select using (bucket_id = 'service-images');
drop policy if exists "service images staff write" on storage.objects;
create policy "service images staff write" on storage.objects for all using (bucket_id = 'service-images' and is_staff()) with check (bucket_id = 'service-images' and is_staff());
drop policy if exists "booking photos owner" on storage.objects;
create policy "booking photos owner" on storage.objects for all
  using (bucket_id = 'booking-photos' and ((storage.foldername(name))[1] = auth.uid()::text or is_staff()))
  with check (bucket_id = 'booking-photos' and (storage.foldername(name))[1] = auth.uid()::text);
