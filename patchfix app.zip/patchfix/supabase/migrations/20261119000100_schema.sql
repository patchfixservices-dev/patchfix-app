-- PatchFix schema. Safe to re-run (idempotent where practical).
create extension if not exists "pgcrypto";

-- ---------- enums ----------
do $$ begin
  create type app_role as enum ('admin','staff','professional','customer');
exception when duplicate_object then null; end $$;
do $$ begin
  create type booking_status as enum ('received','confirmed','assigned','in_progress','completed','cancelled');
exception when duplicate_object then null; end $$;
do $$ begin
  create type payment_method as enum ('online','cash');
exception when duplicate_object then null; end $$;
do $$ begin
  create type payment_status as enum ('pending','paid','failed','refunded','cash_pending','cash_collected');
exception when duplicate_object then null; end $$;

-- ---------- helpers ----------
create or replace function set_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;

-- ---------- identity ----------
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  phone text,
  email text,
  expo_push_token text,
  notifications_enabled boolean not null default true,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
drop trigger if exists profiles_updated on profiles;
create trigger profiles_updated before update on profiles for each row execute function set_updated_at();

create table if not exists user_roles (
  user_id uuid not null references auth.users(id) on delete cascade,
  role app_role not null,
  primary key (user_id, role)
);

create or replace function has_role(r app_role) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from user_roles where user_id = auth.uid() and role = r);
$$;
create or replace function is_staff() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from user_roles where user_id = auth.uid() and role in ('admin','staff'));
$$;

-- new auth user -> profile
create or replace function handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, phone, email, full_name)
  values (new.id, new.phone, new.email, new.raw_user_meta_data->>'full_name')
  on conflict (id) do nothing;
  insert into user_roles (user_id, role) values (new.id, 'customer') on conflict do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

-- ---------- geography ----------
create table if not exists cities (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  state text not null,
  is_active boolean not null default false,
  price_adjustment_pct numeric(5,2) not null default 0,
  created_at timestamptz not null default now()
);
create table if not exists service_areas (
  id uuid primary key default gen_random_uuid(),
  city_id uuid not null references cities(id) on delete cascade,
  pincode text not null check (pincode ~ '^[1-9][0-9]{5}$'),
  area_name text,
  is_active boolean not null default true,
  unique (city_id, pincode)
);
create index if not exists service_areas_pincode_idx on service_areas(pincode) where is_active;

-- ---------- catalog ----------
create table if not exists service_categories (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  name text not null,
  image_url text,
  sort_order int not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists services (
  id uuid primary key default gen_random_uuid(),
  category_id uuid not null references service_categories(id) on delete cascade,
  slug text not null unique,
  group_name text,
  name text not null,
  keywords text[] not null default '{}',
  description text,
  benefits text[] not null default '{}',
  included text[] not null default '{}',
  not_included text[] not null default '{}',
  faqs jsonb not null default '[]',
  duration_minutes int not null default 60,
  base_price numeric(10,2) not null default 0,
  is_quote_only boolean not null default false,
  price_is_estimate boolean not null default true,
  image_url text,
  is_featured boolean not null default false,
  is_popular boolean not null default false,
  sort_order int not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
drop trigger if exists services_updated on services;
create trigger services_updated before update on services for each row execute function set_updated_at();
create index if not exists services_category_idx on services(category_id) where is_active;
create index if not exists services_name_trgm on services using gin (to_tsvector('simple', name));

create table if not exists service_variants (
  id uuid primary key default gen_random_uuid(),
  service_id uuid not null references services(id) on delete cascade,
  name text not null,
  price numeric(10,2) not null check (price >= 0),
  is_addon boolean not null default false,
  is_active boolean not null default true
);
create table if not exists service_images (
  id uuid primary key default gen_random_uuid(),
  service_id uuid not null references services(id) on delete cascade,
  url text not null,
  sort_order int not null default 0
);

-- ---------- addresses ----------
create table if not exists addresses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  label text not null default 'Home',
  line1 text not null,
  line2 text,
  landmark text,
  city_id uuid references cities(id),
  pincode text not null check (pincode ~ '^[1-9][0-9]{5}$'),
  latitude double precision,
  longitude double precision,
  is_default boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists addresses_user_idx on addresses(user_id);

-- ---------- professionals ----------
create table if not exists professionals (
  id uuid primary key default gen_random_uuid(),
  user_id uuid unique references auth.users(id) on delete set null,
  full_name text not null,
  phone text not null,
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);
create table if not exists professional_services (
  professional_id uuid references professionals(id) on delete cascade,
  category_id uuid references service_categories(id) on delete cascade,
  primary key (professional_id, category_id)
);
create table if not exists professional_availability (
  id uuid primary key default gen_random_uuid(),
  professional_id uuid not null references professionals(id) on delete cascade,
  weekday smallint not null check (weekday between 0 and 6),
  start_time time not null,
  end_time time not null
);

-- ---------- bookings ----------
create sequence if not exists booking_ref_seq start 1001;
create table if not exists bookings (
  id uuid primary key default gen_random_uuid(),
  reference text not null unique default ('PF-' || to_char(now() at time zone 'Asia/Kolkata','YYMM') || '-' || nextval('booking_ref_seq')),
  user_id uuid not null references auth.users(id),
  address_id uuid not null references addresses(id),
  city_id uuid not null references cities(id),
  scheduled_date date not null,
  slot text not null,
  status booking_status not null default 'received',
  customer_name text not null,
  customer_phone text not null,
  notes text,
  photo_paths text[] not null default '{}',
  subtotal numeric(10,2) not null,
  fees numeric(10,2) not null default 0,
  tax numeric(10,2) not null default 0,
  discount numeric(10,2) not null default 0,
  total numeric(10,2) not null,
  is_estimate boolean not null default false,
  coupon_code text,
  payment_method payment_method not null,
  payment_status payment_status not null,
  idempotency_key text not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, idempotency_key)
);
drop trigger if exists bookings_updated on bookings;
create trigger bookings_updated before update on bookings for each row execute function set_updated_at();
create index if not exists bookings_user_idx on bookings(user_id, created_at desc);
create index if not exists bookings_slot_idx on bookings(city_id, scheduled_date, slot) where status <> 'cancelled';

create table if not exists booking_items (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references bookings(id) on delete cascade,
  service_id uuid not null references services(id),
  variant_id uuid references service_variants(id),
  name text not null,
  unit_price numeric(10,2) not null,
  quantity int not null check (quantity between 1 and 20)
);
create table if not exists booking_status_history (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references bookings(id) on delete cascade,
  status booking_status not null,
  note text,
  changed_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create table if not exists booking_assignments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references bookings(id) on delete cascade,
  professional_id uuid not null references professionals(id),
  assigned_by uuid references auth.users(id),
  assigned_at timestamptz not null default now(),
  unique (booking_id)
);

-- ---------- payments ----------
create table if not exists payments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references bookings(id) on delete cascade,
  method payment_method not null,
  status payment_status not null,
  amount numeric(10,2) not null,
  razorpay_order_id text unique,
  razorpay_payment_id text unique,
  collected_by uuid references auth.users(id),
  collected_at timestamptz,
  created_at timestamptz not null default now()
);
create table if not exists payment_events (
  id uuid primary key default gen_random_uuid(),
  event_id text unique,            -- Razorpay event id => idempotent webhook
  event_type text not null,
  payload jsonb not null,
  processed_at timestamptz not null default now()
);

-- ---------- promotions / reviews ----------
create table if not exists coupons (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  discount_type text not null check (discount_type in ('percent','fixed')),
  discount_value numeric(10,2) not null check (discount_value > 0),
  min_amount numeric(10,2) not null default 0,
  max_discount numeric(10,2),
  expires_at timestamptz,
  usage_limit int,
  used_count int not null default 0,
  is_active boolean not null default true
);
create table if not exists coupon_redemptions (
  id uuid primary key default gen_random_uuid(),
  coupon_id uuid not null references coupons(id),
  user_id uuid not null references auth.users(id),
  booking_id uuid not null references bookings(id) on delete cascade,
  created_at timestamptz not null default now(),
  unique (coupon_id, booking_id)
);
create table if not exists reviews (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null unique references bookings(id) on delete cascade,
  service_id uuid not null references services(id),
  user_id uuid not null references auth.users(id),
  rating smallint not null check (rating between 1 and 5),
  comment text,
  is_published boolean not null default false,   -- admin moderation
  created_at timestamptz not null default now()
);

-- ---------- misc ----------
create table if not exists notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  body text not null,
  data jsonb not null default '{}',
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_idx on notifications(user_id, created_at desc);
create table if not exists app_settings (
  key text primary key,
  value jsonb not null,
  updated_at timestamptz not null default now()
);
create table if not exists support_requests (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  booking_id uuid references bookings(id),
  subject text not null,
  message text not null,
  status text not null default 'open',
  created_at timestamptz not null default now()
);
create table if not exists audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id),
  action text not null,
  entity text not null,
  entity_id text,
  details jsonb,
  created_at timestamptz not null default now()
);

-- audit trigger for admin-managed tables
create or replace function audit_change() returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into audit_logs(actor_id, action, entity, entity_id, details)
  values (auth.uid(), tg_op, tg_table_name,
          coalesce((case when tg_op='DELETE' then old.id else new.id end)::text, ''),
          to_jsonb(case when tg_op='DELETE' then old else new end));
  return null;
end $$;
do $$ declare t text; begin
  foreach t in array array['services','service_categories','cities','service_areas','coupons','professionals','booking_assignments'] loop
    execute format('drop trigger if exists audit_%1$s on %1$s', t);
    execute format('create trigger audit_%1$s after insert or update or delete on %1$s for each row execute function audit_change()', t);
  end loop;
end $$;

-- booking status history auto-log
create or replace function log_booking_status() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'INSERT' or new.status is distinct from old.status then
    insert into booking_status_history(booking_id, status, changed_by) values (new.id, new.status, auth.uid());
  end if;
  return new;
end $$;
drop trigger if exists bookings_status_log on bookings;
create trigger bookings_status_log after insert or update of status on bookings for each row execute function log_booking_status();
