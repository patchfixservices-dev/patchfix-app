-- Staff can suspend/restore customers via a checked RPC (column-level grants stop customers editing is_active).
create or replace function set_customer_active(p_id uuid, p_active boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if not is_staff() then raise exception 'forbidden'; end if;
  update profiles set is_active = p_active where id = p_id;
  insert into audit_logs(actor_id, action, entity, entity_id, details) values (auth.uid(), 'SET_ACTIVE', 'profiles', p_id::text, jsonb_build_object('active', p_active));
end $$;
grant execute on function set_customer_active to authenticated;

-- Suspended customers cannot create bookings.
create or replace function block_inactive_customer() returns trigger language plpgsql security definer set search_path = public as $$
begin
  if exists (select 1 from profiles where id = new.user_id and not is_active) then raise exception 'account_suspended'; end if;
  return new;
end $$;
drop trigger if exists bookings_block_inactive on bookings;
create trigger bookings_block_inactive before insert on bookings for each row execute function block_inactive_customer();
