// Database Webhook target: on INSERT into public.notifications, deliver an Expo push to the user's device.
// Configure in Supabase: Database > Webhooks > notifications INSERT -> this function (add header x-webhook-secret).
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
Deno.serve(async (req) => {
  if (req.headers.get('x-webhook-secret') !== Deno.env.get('PUSH_WEBHOOK_SECRET')) return new Response('forbidden', { status: 403 });
  const { record } = await req.json();
  const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
  const { data: prof } = await admin.from('profiles').select('expo_push_token, notifications_enabled').eq('id', record.user_id).single();
  if (!prof?.expo_push_token || !prof.notifications_enabled) return new Response('no token');
  const r = await fetch('https://exp.host/--/api/v2/push/send', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ to: prof.expo_push_token, title: record.title, body: record.body, data: record.data, channelId: 'default' }),
  });
  return new Response(await r.text(), { status: r.status });
});
