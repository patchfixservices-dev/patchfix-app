// Creates a Razorpay order for an existing booking owned by the caller.
// Amount is read from the DB (never from the client). Secrets live only in Supabase function secrets.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders, json } from '../_shared/cors.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });
  try {
    const authHeader = req.headers.get('Authorization') ?? '';
    const userClient = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, {
      global: { headers: { Authorization: authHeader } },
    });
    const { data: { user } } = await userClient.auth.getUser();
    if (!user) return json({ error: 'unauthorized' }, 401);

    const { booking_id } = await req.json();
    // RLS guarantees the caller can only read their own booking
    const { data: booking, error } = await userClient.from('bookings')
      .select('id, reference, total, payment_method, payment_status').eq('id', booking_id).single();
    if (error || !booking) return json({ error: 'booking_not_found' }, 404);
    if (booking.payment_method !== 'online' || booking.payment_status !== 'pending') return json({ error: 'not_payable' }, 400);

    const key = Deno.env.get('RAZORPAY_KEY_ID')!, secret = Deno.env.get('RAZORPAY_KEY_SECRET')!;
    const res = await fetch('https://api.razorpay.com/v1/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: 'Basic ' + btoa(`${key}:${secret}`) },
      body: JSON.stringify({
        amount: Math.round(Number(booking.total) * 100), currency: 'INR',
        receipt: booking.reference, notes: { booking_id: booking.id },
      }),
    });
    const order = await res.json();
    if (!res.ok) return json({ error: 'razorpay_error', detail: order?.error?.description }, 502);

    const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);
    await admin.from('payments').update({ razorpay_order_id: order.id }).eq('booking_id', booking.id).eq('method', 'online');
    return json({ order_id: order.id, amount: order.amount, currency: order.currency, key_id: key });
  } catch (e) {
    return json({ error: String(e) }, 500);
  }
});
