// Razorpay webhook: verifies HMAC signature, is idempotent (payment_events.event_id unique),
// and is the ONLY place an online payment becomes "paid".
// Deploy with --no-verify-jwt (Razorpay does not send a Supabase JWT).
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

async function hmacHex(secret: string, body: string) {
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(body));
  return [...new Uint8Array(sig)].map((b) => b.toString(16).padStart(2, '0')).join('');
}
const safeEqual = (a: string, b: string) => a.length === b.length && [...a].reduce((x, c, i) => x | (c.charCodeAt(0) ^ b.charCodeAt(i)), 0) === 0;

Deno.serve(async (req) => {
  const raw = await req.text();
  const sig = req.headers.get('x-razorpay-signature') ?? '';
  const expected = await hmacHex(Deno.env.get('RAZORPAY_WEBHOOK_SECRET')!, raw);
  if (!safeEqual(sig, expected)) return new Response('invalid signature', { status: 400 });

  const eventId = req.headers.get('x-razorpay-event-id') ?? '';
  const event = JSON.parse(raw);
  const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

  // idempotency: unique event_id insert fails on replay
  const { error: dup } = await admin.from('payment_events').insert({ event_id: eventId || null, event_type: event.event, payload: event });
  if (dup) return new Response('duplicate', { status: 200 });

  const p = event.payload?.payment?.entity;
  const orderId = p?.order_id as string | undefined;
  if (!orderId) return new Response('ok');

  const { data: pay } = await admin.from('payments').select('id, booking_id, amount').eq('razorpay_order_id', orderId).maybeSingle();
  if (!pay) return new Response('unknown order', { status: 200 });

  if (event.event === 'payment.captured' || event.event === 'order.paid') {
    if (Math.round(Number(pay.amount) * 100) !== p.amount) return new Response('amount mismatch', { status: 200 });
    await admin.from('payments').update({ status: 'paid', razorpay_payment_id: p.id }).eq('id', pay.id);
    await admin.from('bookings').update({ payment_status: 'paid' }).eq('id', pay.booking_id);
    const { data: b } = await admin.from('bookings').select('user_id, reference').eq('id', pay.booking_id).single();
    if (b) await admin.from('notifications').insert({ user_id: b.user_id, title: 'Payment received', body: `Payment for ${b.reference} was successful.`, data: { booking_id: pay.booking_id } });
  } else if (event.event === 'payment.failed') {
    await admin.from('payments').update({ status: 'failed' }).eq('id', pay.id);
    await admin.from('bookings').update({ payment_status: 'failed' }).eq('id', pay.booking_id);
  } else if (event.event === 'refund.processed') {
    await admin.from('payments').update({ status: 'refunded' }).eq('id', pay.id);
    await admin.from('bookings').update({ payment_status: 'refunded' }).eq('id', pay.booking_id);
  }
  return new Response('ok');
});
