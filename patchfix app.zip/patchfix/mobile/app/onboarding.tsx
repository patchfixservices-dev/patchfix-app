import React, { useRef, useState } from 'react';
import { Dimensions, FlatList, Pressable, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Home, ShieldCheck, CreditCard } from 'lucide-react-native';
import { Button } from '@/components/ui';
import { colors } from '@/lib/theme';

const { width } = Dimensions.get('window');
const slides = [
  { Icon: Home, title: 'Home services made easy', body: 'Electrical, plumbing, appliances, cleaning and moving — all in one app.' },
  { Icon: ShieldCheck, title: 'Trusted professionals', body: 'Verified technicians you can rely on, right at your doorstep.' },
  { Icon: CreditCard, title: 'Simple and secure booking', body: 'Pick a slot, pay online or after service. Track every step.' },
];

export default function Onboarding() {
  const router = useRouter();
  const [i, setI] = useState(0);
  const ref = useRef<FlatList>(null);
  const finish = async () => { await AsyncStorage.setItem('onboarded', '1'); router.replace('/(auth)/login'); };
  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: colors.white }}>
      <Pressable onPress={finish} style={{ alignSelf: 'flex-end', padding: 16 }} accessibilityRole="button"><Text style={{ color: colors.muted }}>Skip</Text></Pressable>
      <FlatList ref={ref} data={slides} horizontal pagingEnabled showsHorizontalScrollIndicator={false} keyExtractor={(x) => x.title}
        onMomentumScrollEnd={(e) => setI(Math.round(e.nativeEvent.contentOffset.x / width))}
        renderItem={({ item: { Icon, title, body } }) => (
          <View style={{ width, alignItems: 'center', justifyContent: 'center', padding: 32 }}>
            <View style={{ width: 140, height: 140, borderRadius: 70, backgroundColor: colors.grey, alignItems: 'center', justifyContent: 'center' }}><Icon size={64} color={colors.charcoal} /></View>
            <Text style={{ fontSize: 24, fontWeight: '800', color: colors.charcoal, marginTop: 32, textAlign: 'center' }}>{title}</Text>
            <Text style={{ color: colors.muted, textAlign: 'center', marginTop: 12, fontSize: 16 }}>{body}</Text>
          </View>)} />
      <View style={{ flexDirection: 'row', justifyContent: 'center', marginBottom: 16 }}>
        {slides.map((_, k) => <View key={k} style={{ width: k === i ? 22 : 8, height: 8, borderRadius: 4, marginHorizontal: 3, backgroundColor: k === i ? colors.yellow : colors.border }} />)}
      </View>
      <View style={{ padding: 24 }}>
        <Button title={i === slides.length - 1 ? 'Get started' : 'Next'} onPress={() => (i === slides.length - 1 ? finish() : ref.current?.scrollToIndex({ index: i + 1 }))} />
      </View>
    </SafeAreaView>
  );
}
