import React, { useState } from 'react';
import { Alert, FlatList, Text, TextInput, View, Pressable, ScrollView } from 'react-native';
import MapView, { Marker, MapPressEvent } from 'react-native-maps';
import * as Location from 'expo-location';
import { Trash2 } from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { useAddresses, useDeleteAddress, useSaveAddress } from '@/lib/api';
import { Button, Empty, ErrorState, Loading } from '@/components/ui';
import { colors, radius } from '@/lib/theme';

const COIMBATORE = { latitude: 11.0168, longitude: 76.9558 };

export default function Addresses() {
  const { data, isLoading, isError, refetch } = useAddresses();
  const save = useSaveAddress();
  const del = useDeleteAddress();
  const [adding, setAdding] = useState(false);
  const [f, setF] = useState({ label: 'Home', line1: '', line2: '', landmark: '', pincode: '' });
  const [pin, setPin] = useState(COIMBATORE);
  const [query, setQuery] = useState('');
  const [msg, setMsg] = useState('');

  const checkPin = async (p: string) => {
    setF((x) => ({ ...x, pincode: p })); setMsg('');
    if (/^[1-9][0-9]{5}$/.test(p)) {
      const { data: r } = await supabase.rpc('check_serviceable', { p_pincode: p });
      setMsg(r?.length ? `✓ We serve ${r[0].city_name}` : 'We do not serve this PIN code yet.');
    }
  };
  const fillFrom = async (c: { latitude: number; longitude: number }) => {
    setPin(c);
    try {
      const [a] = await Location.reverseGeocodeAsync(c);
      if (a) { setF((x) => ({ ...x, line1: x.line1 || [a.name, a.street, a.district].filter(Boolean).join(', ') })); if (a.postalCode) checkPin(a.postalCode.replace(/\s/g, '')); }
    } catch { /* offline geocoder: user can type manually */ }
  };
  const useMyLocation = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') return Alert.alert('Permission needed', 'Allow location access or enter your address manually.');
    const p = await Location.getCurrentPositionAsync({});
    fillFrom(p.coords);
  };
  const searchPlace = async () => {
    try { const r = await Location.geocodeAsync(query + ', India'); if (r[0]) fillFrom(r[0]); else Alert.alert('Not found', 'Try a different search or drop the pin on the map.'); }
    catch { Alert.alert('Search unavailable', 'Drop the pin on the map or type the address.'); }
  };
  const submit = async () => {
    if (f.line1.trim().length < 5 || !/^[1-9][0-9]{5}$/.test(f.pincode)) return setMsg('Enter a full address and a valid 6-digit PIN code.');
    try {
      await save.mutateAsync({ label: f.label, line1: f.line1.trim(), line2: f.line2 || null, landmark: f.landmark || null, pincode: f.pincode, latitude: pin.latitude, longitude: pin.longitude });
      setAdding(false); setF({ label: 'Home', line1: '', line2: '', landmark: '', pincode: '' });
    } catch { setMsg('Could not save address. Please retry.'); }
  };

  if (isLoading) return <Loading />;
  if (isError) return <ErrorState onRetry={refetch} />;
  const input = { borderWidth: 1, borderColor: colors.border, backgroundColor: colors.grey, borderRadius: 12, padding: 12, fontSize: 15, marginBottom: 10 } as const;

  if (adding) return (
    <ScrollView contentContainerStyle={{ padding: 16 }} keyboardShouldPersistTaps="handled">
      <View style={{ flexDirection: 'row' }}>
        <TextInput value={query} onChangeText={setQuery} placeholder="Search area or landmark" style={[input, { flex: 1, marginRight: 8 }]} accessibilityLabel="Search location" />
        <Button title="Find" onPress={searchPlace} style={{ minHeight: 46, paddingVertical: 10 }} />
      </View>
      <MapView style={{ height: 220, borderRadius: radius.md, marginBottom: 10 }} region={{ ...pin, latitudeDelta: 0.01, longitudeDelta: 0.01 }} onPress={(e: MapPressEvent) => fillFrom(e.nativeEvent.coordinate)}>
        <Marker coordinate={pin} draggable onDragEnd={(e) => fillFrom(e.nativeEvent.coordinate)} />
      </MapView>
      <Button title="Use my current location" variant="outline" onPress={useMyLocation} style={{ marginBottom: 12 }} />
      <TextInput value={f.label} onChangeText={(v) => setF({ ...f, label: v })} placeholder="Label (Home, Office)" style={input} />
      <TextInput value={f.line1} onChangeText={(v) => setF({ ...f, line1: v })} placeholder="House / flat, street, area" style={input} accessibilityLabel="Address line 1" />
      <TextInput value={f.line2} onChangeText={(v) => setF({ ...f, line2: v })} placeholder="Address line 2 (optional)" style={input} />
      <TextInput value={f.landmark} onChangeText={(v) => setF({ ...f, landmark: v })} placeholder="Landmark (optional)" style={input} />
      <TextInput value={f.pincode} onChangeText={checkPin} placeholder="PIN code" keyboardType="number-pad" maxLength={6} style={input} accessibilityLabel="PIN code" />
      {!!msg && <Text style={{ color: msg.startsWith('✓') ? colors.success : colors.danger, marginBottom: 8 }}>{msg}</Text>}
      <Button title="Save address" onPress={submit} loading={save.isPending} />
      <Button title="Cancel" variant="outline" onPress={() => setAdding(false)} style={{ marginTop: 10 }} />
    </ScrollView>
  );

  return (
    <View style={{ flex: 1, padding: 16 }}>
      <FlatList data={data} keyExtractor={(a) => a.id} ListEmptyComponent={<Empty text="No saved addresses yet." />} contentContainerStyle={{ flexGrow: 1 }}
        renderItem={({ item: a }) => (
          <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: colors.grey, borderRadius: radius.md, padding: 14, marginBottom: 10 }}>
            <View style={{ flex: 1 }}><Text style={{ fontWeight: '700', color: colors.charcoal }}>{a.label}</Text><Text style={{ color: colors.charcoal }}>{a.line1}{a.line2 ? `, ${a.line2}` : ''}</Text><Text style={{ color: colors.muted }}>{a.pincode}</Text></View>
            <Pressable onPress={() => Alert.alert('Delete address?', '', [{ text: 'Cancel' }, { text: 'Delete', style: 'destructive', onPress: () => del.mutate(a.id) }])} accessibilityLabel="Delete address" style={{ padding: 8 }}><Trash2 size={18} color={colors.danger} /></Pressable>
          </View>)} />
      <Button title="Add new address" onPress={() => setAdding(true)} />
    </View>
  );
}
