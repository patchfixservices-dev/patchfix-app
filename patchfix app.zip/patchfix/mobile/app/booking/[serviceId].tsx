import React, { useMemo, useRef, useState } from 'react';
import { Alert, Image as RNImage, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useQueryClient } from '@tanstack/react-query';
import { friendly, useAddresses, useProfile, useServiceById, useSettings, useSlots } from '@/lib/api';
import { Button, ErrorState, Loading } from '@/components/ui';
import { supabase } from '@/lib/supabase';
import { payOnline } from '@/lib/payment';
import { colors, radius } from '@/lib/theme';
import { dateLabel, inr, slotLabel } from '@/lib/format';

const STEPS = ['Options', 'Address', 'Date & time', 'Details', 'Review & pay'];
const ymd = (d: Date) => new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
const chip = (on: boolean) => ({ paddingVertical: 10, paddingHorizontal: 14, borderRadius: 12, marginRight: 8, marginBottom: 8, backgroundColor: on ? colors.yellow : colors.grey } as const);

export default function BookingFlow() {
  const { serviceId } = useLocalSearchParams<{ serviceId: string }>();
  const router = useRouter();
  const qc = useQueryClient();
  const svc = useServiceById(serviceId);
  const addrs = useAddresses();
  const profile = useProfile();
  const settings = useSettings();
  const idem = useRef(`${Date.now()}-${Math.random().toString(36).slice(2)}`).current;

  const [step, setStep] = useState(0);
  const [qty, setQty] = useState(1);
  const [variantIds, setVariantIds] = useState<string[]>([]);
  const [addressId, setAddressId] = useState<string | null>(null);
  const [cityId, setCityId] = useState<string | null>(null);
  const [date, setDate] = useState(ymd(new Date()));
  const [slot, setSlot] = useState<string | null>(null);
  const [name, setName] = useState(''); const [phone, setPhone] = useState(''); const [notes, setNotes] = useState('');
  const [photos, setPhotos] = useState<string[]>([]);
  const [method, setMethod] = useState<'online' | 'cash'>('cash');
  const [coupon, setCoupon] = useState(''); const [discount, setDiscount] = useState(0);
  const [busy, setBusy] = useState(false);
  const submitting = useRef(false);

  const slots = useSlots(cityId, date);
  const days = useMemo(() => Array.from({ length: 7 }, (_, i) => { const d = new Date(); d.setDate(d.getDate() + i); return ymd(d); }), []);

  if (svc.isLoading || addrs.isLoading) return <Loading />;
  if (svc.isError || !svc.data) return <ErrorState onRetry={() => svc.refetch()} />;
  const { service, variants } = svc.data;
  const chosen = variants.filter((v) => variantIds.includes(v.id));
  const subtotal = service.base_price * qty + chosen.reduce((a, v) => a + v.price, 0);
  const fee = Number(settings.data?.platform_fee ?? 0);
  const taxPct = Number(settings.data?.tax_percent ?? 0);
  const tax = Math.round(((subtotal + fee - discount) * taxPct) / 100);
  const total = subtotal + fee - discount + tax;
  const address = addrs.data?.find((a) => a.id === addressId);
  const policy = (settings.data?.cancellation_policy as string) ?? '';

  const pickAddress = async (id: string, pincode: string) => {
    setAddressId(id); setSlot(null);
    const { data } = await supabase.rpc('check_serviceable', { p_pincode: pincode });
    setCityId(data?.[0]?.city_id ?? null);
    if (!data?.length) Alert.alert('Not serviceable', 'Sorry, we do not serve this PIN code yet. Choose another address.');
  };
  const addPhoto = async () => {
    if (photos.length >= 3) return;
    const r = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ['images'], quality: 0.6, allowsEditing: false });
    if (!r.canceled) setPhotos([...photos, r.assets[0].uri]);
  };
  const takePhoto = async () => {
    if (photos.length >= 3) return;
    const p = await ImagePicker.requestCameraPermissionsAsync();
    if (!p.granted) return Alert.alert('Camera permission needed');
    const r = await ImagePicker.launchCameraAsync({ quality: 0.6 });
    if (!r.canceled) setPhotos([...photos, r.assets[0].uri]);
  };
  const applyCoupon = async () => {
    const { data } = await supabase.rpc('preview_coupon', { p_code: coupon, p_subtotal: subtotal });
    const d = Number(data ?? 0); setDiscount(d);
    if (!d) Alert.alert('Coupon not applicable', 'Check the code, expiry and minimum amount.');
  };

  const effName = name || profile.data?.full_name || '';
  const can = [true, !!addressId && !!cityId, !!slot, effName.trim().length >= 2 && /^[0-9]{10}$/.test(phone.replace(/^\+91/, '')), true][step];

  const confirm = async () => {
    if (submitting.current) return; // prevent duplicate submit
    submitting.current = true; setBusy(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const paths: string[] = [];
      for (let i = 0; i < photos.length; i++) {
        const buf = await (await fetch(photos[i])).arrayBuffer();
        const path = `${user!.id}/${idem}/${i}.jpg`;
        const { error } = await supabase.storage.from('booking-photos').upload(path, buf, { contentType: 'image/jpeg', upsert: true });
        if (!error) paths.push(path);
      }
      const { data, error } = await supabase.rpc('create_booking', {
        p_service_id: service.id, p_variant_ids: variantIds, p_quantity: qty, p_address_id: addressId, p_date: date, p_slot: slot,
        p_name: effName, p_phone: phone.replace(/^\+91/, ''), p_notes: notes || null, p_payment_method: method, p_coupon: coupon || null, p_idempotency_key: idem, p_photo_paths: paths,
      });
      if (error) throw new Error(error.message);
      const booking = data as { id: string; reference: string };
      qc.invalidateQueries({ queryKey: ['bookings'] });
      if (method === 'online') {
        try {
          const r = await payOnline(booking, { name, phone, email: profile.data?.email });
          if (r === 'unavailable') Alert.alert('Online payment unavailable here', 'Online payment works in the installed PatchFix app. Your booking is saved; payment stays pending.');
        } catch { Alert.alert('Payment not started', 'Your booking is saved. You can retry payment from My Bookings.'); }
      }
      router.replace(`/booking-confirmed/${booking.id}`);
    } catch (e) {
      Alert.alert('Booking failed', friendly(e));
      submitting.current = false; setBusy(false);
    }
  };

  const row = (a: string, b: string, bold?: boolean) => <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 }}><Text style={{ color: colors.charcoal, fontWeight: bold ? '800' : '400' }}>{a}</Text><Text style={{ color: colors.charcoal, fontWeight: bold ? '800' : '400' }}>{b}</Text></View>;
  const input = { borderWidth: 1, borderColor: colors.border, backgroundColor: colors.grey, borderRadius: 12, padding: 12, fontSize: 15, marginBottom: 10 } as const;

  return (
    <SafeAreaView style={{ flex: 1 }} edges={['bottom']}>
      <Stack.Screen options={{ title: service.name }} />
      <View style={{ flexDirection: 'row', padding: 16, paddingBottom: 0 }}>
        {STEPS.map((_, i) => <View key={i} style={{ flex: 1, height: 4, marginRight: 4, borderRadius: 2, backgroundColor: i <= step ? colors.yellow : colors.border }} />)}
      </View>
      <Text style={{ paddingHorizontal: 16, paddingTop: 8, color: colors.muted }}>Step {step + 1} of {STEPS.length} · {STEPS[step]}</Text>
      <ScrollView contentContainerStyle={{ padding: 16 }} keyboardShouldPersistTaps="handled">
        {step === 0 && (<>
          <Text style={{ fontWeight: '700', color: colors.charcoal, marginBottom: 8 }}>Quantity</Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 16 }}>
            <Pressable onPress={() => setQty(Math.max(1, qty - 1))} style={chip(false)} accessibilityLabel="Decrease quantity"><Text style={{ fontSize: 18 }}>−</Text></Pressable>
            <Text style={{ fontSize: 18, fontWeight: '700', marginHorizontal: 12 }}>{qty}</Text>
            <Pressable onPress={() => setQty(Math.min(10, qty + 1))} style={chip(false)} accessibilityLabel="Increase quantity"><Text style={{ fontSize: 18 }}>+</Text></Pressable>
          </View>
          {variants.length > 0 && <Text style={{ fontWeight: '700', color: colors.charcoal, marginBottom: 8 }}>Options & add-ons</Text>}
          <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
            {variants.map((v) => { const on = variantIds.includes(v.id); return (
              <Pressable key={v.id} onPress={() => setVariantIds(on ? variantIds.filter((x) => x !== v.id) : [...variantIds, v.id])} style={chip(on)} accessibilityRole="checkbox" accessibilityState={{ checked: on }}>
                <Text style={{ color: colors.charcoal }}>{v.name} (+{inr(v.price)})</Text></Pressable>); })}
          </View>
          {service.is_quote_only && <Text style={{ color: colors.muted, marginTop: 8 }}>This service needs inspection or distance/volume details. The amount shown is an estimate; the final quote is confirmed by our team.</Text>}
        </>)}

        {step === 1 && (<>
          {addrs.data?.length ? addrs.data.map((a) => (
            <Pressable key={a.id} onPress={() => pickAddress(a.id, a.pincode)} accessibilityRole="radio" accessibilityState={{ selected: a.id === addressId }}
              style={{ padding: 14, borderRadius: radius.md, marginBottom: 10, backgroundColor: colors.grey, borderWidth: 2, borderColor: a.id === addressId ? colors.yellow : 'transparent' }}>
              <Text style={{ fontWeight: '700', color: colors.charcoal }}>{a.label}</Text><Text style={{ color: colors.charcoal }}>{a.line1}</Text><Text style={{ color: colors.muted }}>{a.pincode}</Text>
            </Pressable>)) : <Text style={{ color: colors.muted, marginBottom: 12 }}>You have no saved addresses.</Text>}
          <Button title="Add new address" variant="outline" onPress={() => router.push('/addresses')} />
        </>)}

        {step === 2 && (<>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 12 }}>
            {days.map((d) => <Pressable key={d} onPress={() => { setDate(d); setSlot(null); }} style={chip(d === date)} accessibilityRole="button"><Text style={{ color: colors.charcoal }}>{dateLabel(d)}</Text></Pressable>)}
          </ScrollView>
          {slots.isLoading ? <Loading /> : slots.isError ? <ErrorState onRetry={() => slots.refetch()} /> : (
            <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
              {slots.data?.map((s) => {
                const startH = Number(s.slot.split('-')[0].split(':')[0]);
                const past = date === ymd(new Date()) && startH <= new Date().getHours();
                const off = s.remaining <= 0 || past;
                return <Pressable key={s.slot} disabled={off} onPress={() => setSlot(s.slot)} style={[chip(slot === s.slot), off && { opacity: 0.4 }]} accessibilityRole="button" accessibilityState={{ disabled: off }}>
                  <Text style={{ color: colors.charcoal }}>{slotLabel(s.slot)}{s.remaining <= 0 ? ' · Full' : ''}</Text></Pressable>; })}
            </View>)}
        </>)}

        {step === 3 && (<>
          <TextInput value={effName} onChangeText={setName} placeholder="Your name" style={input} accessibilityLabel="Your name" />
          <TextInput value={phone} onChangeText={setPhone} placeholder="Contact number (10 digits)" keyboardType="number-pad" maxLength={13} style={input} accessibilityLabel="Contact number" />
          <TextInput value={notes} onChangeText={setNotes} placeholder="Service instructions (optional)" multiline style={[input, { height: 90, textAlignVertical: 'top' }]} />
          <Text style={{ fontWeight: '700', color: colors.charcoal, marginBottom: 8 }}>Photos of the issue (optional, max 3)</Text>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginBottom: 8 }}>
            {photos.map((u) => <Pressable key={u} onPress={() => setPhotos(photos.filter((x) => x !== u))} accessibilityLabel="Remove photo"><RNImage source={{ uri: u }} style={{ width: 72, height: 72, borderRadius: 10, marginRight: 8 }} /></Pressable>)}
          </View>
          <View style={{ flexDirection: 'row' }}><Button title="Gallery" variant="outline" onPress={addPhoto} style={{ flex: 1, marginRight: 8 }} /><Button title="Camera" variant="outline" onPress={takePhoto} style={{ flex: 1 }} /></View>
        </>)}

        {step === 4 && (<>
          <View style={{ backgroundColor: colors.grey, borderRadius: radius.md, padding: 14 }}>
            <Text style={{ fontWeight: '800', color: colors.charcoal, marginBottom: 8 }}>{service.name}{qty > 1 ? ` × ${qty}` : ''}</Text>
            {chosen.map((v) => <Text key={v.id} style={{ color: colors.muted }}>+ {v.name}</Text>)}
            <Text style={{ color: colors.charcoal, marginTop: 8 }}>{dateLabel(date)} · {slot ? slotLabel(slot) : ''}</Text>
            <Text style={{ color: colors.charcoal }}>{address?.line1}, {address?.pincode}</Text>
          </View>
          <View style={{ flexDirection: 'row', marginTop: 12 }}>
            <TextInput value={coupon} onChangeText={(v) => { setCoupon(v.toUpperCase()); setDiscount(0); }} placeholder="Coupon code" autoCapitalize="characters" style={[input, { flex: 1, marginBottom: 0, marginRight: 8 }]} />
            <Button title="Apply" variant="outline" onPress={applyCoupon} disabled={!coupon} />
          </View>
          <View style={{ marginTop: 16 }}>
            {row('Service', inr(subtotal))}
            {fee > 0 && row('Fees', inr(fee))}
            {discount > 0 && row('Discount', `− ${inr(discount)}`)}
            {tax > 0 && row(`Tax (${taxPct}%)`, inr(tax))}
            {row(service.price_is_estimate || service.is_quote_only ? 'Estimated total' : 'Total', inr(total), true)}
            <Text style={{ color: colors.muted, fontSize: 12 }}>Final amount is confirmed by the server when you book. Prices are estimates until confirmed.</Text>
          </View>
          <Text style={{ fontWeight: '700', color: colors.charcoal, marginTop: 16, marginBottom: 8 }}>Payment method</Text>
          <View style={{ flexDirection: 'row' }}>
            <Pressable onPress={() => setMethod('cash')} style={chip(method === 'cash')} accessibilityRole="radio"><Text style={{ color: colors.charcoal }}>Cash after service</Text></Pressable>
            <Pressable onPress={() => setMethod('online')} style={chip(method === 'online')} accessibilityRole="radio"><Text style={{ color: colors.charcoal }}>Pay online (UPI / Card)</Text></Pressable>
          </View>
          {!!policy && <Text style={{ color: colors.muted, marginTop: 8 }}>Cancellation policy: {policy}</Text>}
        </>)}
      </ScrollView>
      <View style={{ flexDirection: 'row', padding: 16, borderTopWidth: 1, borderColor: colors.border }}>
        {step > 0 && <Button title="Back" variant="outline" onPress={() => setStep(step - 1)} style={{ marginRight: 10 }} />}
        <Button style={{ flex: 1 }} title={step === STEPS.length - 1 ? `Confirm booking · ${inr(total)}` : 'Continue'} disabled={!can} loading={busy}
          onPress={() => (step === STEPS.length - 1 ? confirm() : setStep(step + 1))} />
      </View>
    </SafeAreaView>
  );
}
