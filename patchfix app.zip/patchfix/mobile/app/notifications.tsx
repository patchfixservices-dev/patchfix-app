import React from 'react';
import { FlatList, Text, View } from 'react-native';
import { useNotifications } from '@/lib/api';
import { Empty, ErrorState, Loading } from '@/components/ui';
import { colors, radius } from '@/lib/theme';

export default function Notifications() {
  const { data, isLoading, isError, refetch } = useNotifications();
  if (isLoading) return <Loading />;
  if (isError) return <ErrorState onRetry={refetch} />;
  return (
    <FlatList data={data} keyExtractor={(n) => n.id} contentContainerStyle={{ padding: 16, flexGrow: 1 }} onRefresh={refetch} refreshing={false}
      ListEmptyComponent={<Empty text="No notifications yet." />}
      renderItem={({ item }) => (
        <View style={{ backgroundColor: colors.grey, borderRadius: radius.md, padding: 14, marginBottom: 10 }}>
          <Text style={{ fontWeight: '700', color: colors.charcoal }}>{item.title}</Text>
          <Text style={{ color: colors.charcoal, marginTop: 2 }}>{item.body}</Text>
          <Text style={{ color: colors.muted, fontSize: 12, marginTop: 4 }}>{new Date(item.created_at).toLocaleString('en-IN')}</Text>
        </View>)} />
  );
}
