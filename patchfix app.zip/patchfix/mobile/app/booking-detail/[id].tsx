import React from 'react';
import { Alert, ScrollView, Text, View } from 'react-native';
import { useLocalSearchParams } from 'expo-router';
import { friendly, useBooking, useCancelBooking } from '@/lib/api';
import { Button, ErrorState, Loading } from '@/components/ui';
import { colors, radius } from '@/lib/theme';
import { dateLabel, inr, slotLabel } from '@/lib/format';
import { PAYMENT_LABEL, STATUS_LABEL } from '@/lib/types';

export default function BookingDetail() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { data: b, isLoading, isError, refetch } = useBooking(id);
  const cancel = useCancelBooking();
  if (isLoading) return <Loading />;
  if (isError || !b) return <ErrorState onRetry={refetch} />;
  const history = [...b.booking_status_history].sort((x, y) => +new Date(x.created_at) - +new Date(y.created_at));
  const canCancel = !['cancelled', 'completed', 'in_progress'].includes(b.status);
  const doCancel = () => Alert.alert('Cancel this booking?', 'This follows the cancellation policy.', [
    { text: 'Keep booking' },
    { text: 'Cancel booking', style: 'destructive', onPress: () => cancel.mutate({ id: b.id }, { onError: (e) => Alert.alert('Cannot cancel', friendly(e)) }) },
  ]);
  const row = (a: string, v: string) => <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 }}><Text style={{ color: colors.muted }}>{a}</Text><Text style={{ color: colors.charcoal, flexShrink: 1, textAlign: 'right' }}>{v}</Text></View>;
  return (
    <ScrollView contentContainerStyle={{ padding: 16 }}>
      <Text style={{ fontSize: 22, fontWeight: '800', color: colors.charcoal }}>{b.reference}</Text>
      <Text style={{ color: colors.charcoal, fontWeight: '600', marginBottom: 12 }}>{STATUS_LABEL[b.status]}</Text>
      <View style={{ backgroundColor: colors.grey, borderRadius: radius.md, padding: 14 }}>
        {b.booking_items.map((i) => row(i.name + (i.quantity > 1 ? ` × ${i.quantity}` : ''), inr(i.unit_price * i.quantity)))}
        {row('Date', dateLabel(b.scheduled_date))}{row('Time', slotLabel(b.slot))}
        {b.addresses && row('Address', `${b.addresses.line1}, ${b.addresses.pincode}`)}
        {row('Payment', `${b.payment_method === 'cash' ? 'Cash after service' : 'Online'} · ${PAYMENT_LABEL[b.payment_status]}`)}
        {b.discount > 0 && row('Discount', `− ${inr(b.discount)}`)}
        {b.tax > 0 && row('Tax', inr(b.tax))}
        {row(b.is_estimate ? 'Estimated total' : 'Total', inr(b.total))}
      </View>
      <Text style={{ fontSize: 17, fontWeight: '700', color: colors.charcoal, marginTop: 20, marginBottom: 10 }}>Status timeline</Text>
      {history.map((h, i) => (
        <View key={h.id} style={{ flexDirection: 'row', marginBottom: 12 }}>
          <View style={{ alignItems: 'center', marginRight: 12 }}>
            <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: i === history.length - 1 ? colors.yellow : colors.charcoal }} />
            {i < history.length - 1 && <View style={{ width: 2, flex: 1, backgroundColor: colors.border }} />}
          </View>
          <View><Text style={{ color: colors.charcoal, fontWeight: '600' }}>{STATUS_LABEL[h.status]}</Text><Text style={{ color: colors.muted, fontSize: 12 }}>{new Date(h.created_at).toLocaleString('en-IN')}</Text></View>
        </View>))}
      {canCancel && <Button title="Cancel booking" variant="outline" onPress={doCancel} loading={cancel.isPending} style={{ marginTop: 16 }} />}
    </ScrollView>
  );
}
