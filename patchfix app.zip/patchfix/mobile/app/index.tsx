import React, { useEffect } from 'react';
import { Text, View } from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useSession } from '@/lib/session';
import { colors } from '@/lib/theme';

// Branded splash -> onboarding (first run) -> login or tabs.
export default function Splash() {
  const router = useRouter();
  const { session, loading } = useSession();
  useEffect(() => {
    if (loading) return;
    const t = setTimeout(async () => {
      const seen = await AsyncStorage.getItem('onboarded');
      if (!seen) router.replace('/onboarding');
      else router.replace(session ? '/(tabs)' : '/(auth)/login');
    }, 1200);
    return () => clearTimeout(t);
  }, [loading, session]);
  return (
    <View style={{ flex: 1, backgroundColor: colors.white, alignItems: 'center', justifyContent: 'center' }}>
      <Image source={require('@/assets/logo.png')} style={{ width: 280, height: 130 }} contentFit="contain" />
      <Text style={{ color: colors.charcoal, letterSpacing: 3, marginTop: 8 }}>TRUSTED BY HOMES</Text>
    </View>
  );
}
