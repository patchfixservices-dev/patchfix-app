import React from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { useCategoryServices } from '@/lib/api';
import { ErrorState, Loading, ServiceImage, Empty } from '@/components/ui';
import { colors, radius } from '@/lib/theme';
import type { Service } from '@/lib/types';

// Image-led service grid grouped under headings (matches reference screenshot 2).
export default function CategoryScreen() {
  const { slug } = useLocalSearchParams<{ slug: string }>();
  const router = useRouter();
  const { data, isLoading, isError, refetch } = useCategoryServices(slug);
  if (isLoading) return <Loading />;
  if (isError || !data) return <ErrorState onRetry={refetch} />;
  const groups = new Map<string, Service[]>();
  data.services.forEach((s) => { const g = s.group_name ?? 'Services'; groups.set(g, [...(groups.get(g) ?? []), s]); });
  return (
    <>
      <Stack.Screen options={{ title: data.category.name }} />
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={{ fontSize: 22, fontWeight: '800', color: colors.charcoal }}>{data.category.name}</Text>
        {data.services.length === 0 && <Empty text="No services available yet." />}
        {[...groups.entries()].map(([g, items]) => (
          <View key={g} style={{ marginTop: 20 }}>
            <Text style={{ fontSize: 16, fontWeight: '700', color: colors.charcoal, marginBottom: 12 }}>{g}</Text>
            <View style={{ flexDirection: 'row', flexWrap: 'wrap', marginHorizontal: -5 }}>
              {items.map((s) => (
                <Pressable key={s.id} onPress={() => router.push(`/service/${s.slug}`)} accessibilityRole="button" accessibilityLabel={s.name}
                  style={({ pressed }) => ({ width: '33.33%', padding: 5, marginBottom: 8, opacity: pressed ? 0.7 : 1 })}>
                  <View style={{ backgroundColor: colors.grey, borderRadius: radius.lg, aspectRatio: 1.1, alignItems: 'center', justifyContent: 'center' }}>
                    <ServiceImage uri={s.image_url} style={{ width: '72%', height: '72%' }} />
                  </View>
                  <Text numberOfLines={2} style={{ textAlign: 'center', color: colors.charcoal, fontSize: 12.5, marginTop: 6 }}>{s.name}</Text>
                </Pressable>))}
            </View>
          </View>))}
      </ScrollView>
    </>
  );
}
