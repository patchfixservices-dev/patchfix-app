import React, { useState } from 'react';
import { Alert, Linking, Text, TextInput, View } from 'react-native';
import { Button } from '@/components/ui';
import { useSettings } from '@/lib/api';
import { supabase } from '@/lib/supabase';
import { colors } from '@/lib/theme';

export default function Help() {
  const { data } = useSettings();
  const [subject, setSubject] = useState(''); const [message, setMessage] = useState(''); const [busy, setBusy] = useState(false);
  const support = (data?.support ?? {}) as { phone?: string; email?: string };
  const submit = async () => {
    setBusy(true);
    const { data: { user } } = await supabase.auth.getUser();
    const { error } = await supabase.from('support_requests').insert({ user_id: user!.id, subject: subject.trim(), message: message.trim() });
    setBusy(false);
    if (error) return Alert.alert('Could not send', 'Please try again.');
    setSubject(''); setMessage(''); Alert.alert('Sent', 'Our team will get back to you.');
  };
  const input = { borderWidth: 1, borderColor: colors.border, backgroundColor: colors.grey, borderRadius: 12, padding: 12, fontSize: 15, marginBottom: 12 } as const;
  return (
    <View style={{ padding: 16 }}>
      {!!support.phone && <Button title={`Call ${support.phone}`} variant="outline" onPress={() => Linking.openURL(`tel:${support.phone}`)} style={{ marginBottom: 16 }} />}
      <Text style={{ fontWeight: '700', color: colors.charcoal, marginBottom: 8 }}>Send us a message</Text>
      <TextInput placeholder="Subject" value={subject} onChangeText={setSubject} style={input} accessibilityLabel="Subject" />
      <TextInput placeholder="How can we help?" value={message} onChangeText={setMessage} multiline style={[input, { height: 120, textAlignVertical: 'top' }]} accessibilityLabel="Message" />
      <Button title="Submit" onPress={submit} loading={busy} disabled={subject.trim().length < 3 || message.trim().length < 5} />
    </View>
  );
}
