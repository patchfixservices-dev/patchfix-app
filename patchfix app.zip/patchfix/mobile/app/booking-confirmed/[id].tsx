import React from 'react';
import { Text, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { CheckCircle2 } from 'lucide-react-native';
import { useBooking } from '@/lib/api';
import { Button, ErrorState, Loading } from '@/components/ui';
import { colors } from '@/lib/theme';
import { dateLabel, inr, slotLabel } from '@/lib/format';
import { PAYMENT_LABEL } from '@/lib/types';

export default function Confirmed() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { data: b, isLoading, isError, refetch } = useBooking(id);
  if (isLoading) return <Loading />;
  if (isError || !b) return <ErrorState onRetry={refetch} />;
  return (
    <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: 24 }}>
      <CheckCircle2 size={72} color={colors.success} />
      <Text style={{ fontSize: 24, fontWeight: '800', color: colors.charcoal, marginTop: 16 }}>Booking received</Text>
      <Text style={{ color: colors.muted, marginTop: 4 }}>Reference {b.reference}</Text>
      <Text style={{ color: colors.charcoal, marginTop: 12 }}>{dateLabel(b.scheduled_date)} · {slotLabel(b.slot)}</Text>
      <Text style={{ color: colors.charcoal }}>{b.is_estimate ? 'Estimated total ' : 'Total '}{inr(b.total)} · {PAYMENT_LABEL[b.payment_status]}</Text>
      <Button title="View booking" onPress={() => router.replace(`/booking-detail/${b.id}`)} style={{ marginTop: 28, alignSelf: 'stretch' }} />
      <Button title="Back to home" variant="outline" onPress={() => router.replace('/(tabs)')} style={{ marginTop: 10, alignSelf: 'stretch' }} />
    </View>
  );
}
