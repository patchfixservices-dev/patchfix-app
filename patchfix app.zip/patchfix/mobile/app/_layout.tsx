import React from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { SessionProvider } from '@/lib/session';
import { colors } from '@/lib/theme';

const qc = new QueryClient({ defaultOptions: { queries: { retry: 1, staleTime: 60_000 } } });

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <QueryClientProvider client={qc}>
        <SessionProvider>
          <StatusBar style="dark" />
          <Stack screenOptions={{ headerStyle: { backgroundColor: colors.white }, headerTintColor: colors.charcoal, headerTitleStyle: { fontWeight: '700' }, contentStyle: { backgroundColor: colors.white } }}>
            <Stack.Screen name="index" options={{ headerShown: false }} />
            <Stack.Screen name="onboarding" options={{ headerShown: false }} />
            <Stack.Screen name="(auth)" options={{ headerShown: false }} />
            <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
            <Stack.Screen name="category/[slug]" options={{ title: '' }} />
            <Stack.Screen name="service/[slug]" options={{ title: '' }} />
            <Stack.Screen name="search" options={{ title: 'Search' }} />
            <Stack.Screen name="booking/[serviceId]" options={{ title: 'Book service' }} />
            <Stack.Screen name="booking-confirmed/[id]" options={{ title: 'Booking', headerBackVisible: false }} />
            <Stack.Screen name="booking-detail/[id]" options={{ title: 'Booking details' }} />
            <Stack.Screen name="addresses" options={{ title: 'Saved addresses' }} />
            <Stack.Screen name="notifications" options={{ title: 'Notifications' }} />
            <Stack.Screen name="help" options={{ title: 'Help & Support' }} />
          </Stack>
        </SessionProvider>
      </QueryClientProvider>
    </SafeAreaProvider>
  );
}
