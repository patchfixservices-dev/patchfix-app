import React, { useState } from 'react';
import { Text, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button } from '@/components/ui';
import { supabase } from '@/lib/supabase';
import { colors } from '@/lib/theme';

const schema = z.object({ full_name: z.string().trim().min(2, 'Enter your name'), email: z.string().trim().email('Enter a valid email').or(z.literal('')) });
type F = z.infer<typeof schema>;

export default function Register() {
  const router = useRouter();
  const [err, setErr] = useState('');
  const { control, handleSubmit, formState: { errors, isSubmitting } } = useForm<F>({ resolver: zodResolver(schema), defaultValues: { full_name: '', email: '' } });
  const save = handleSubmit(async (v) => {
    const { data: { user } } = await supabase.auth.getUser();
    const { error } = await supabase.from('profiles').update({ full_name: v.full_name, email: v.email || null }).eq('id', user!.id);
    if (error) return setErr('Could not save. Please retry.');
    router.replace('/(tabs)');
  });
  const field = (name: keyof F, label: string, kb: any = 'default') => (
    <View style={{ marginBottom: 14 }}>
      <Text style={{ color: colors.charcoal, fontWeight: '600', marginBottom: 6 }}>{label}</Text>
      <Controller control={control} name={name} render={({ field }) => (
        <TextInput value={field.value} onChangeText={field.onChange} keyboardType={kb} autoCapitalize={name === 'email' ? 'none' : 'words'} accessibilityLabel={label}
          style={{ borderWidth: 1, borderColor: colors.border, backgroundColor: colors.grey, borderRadius: 12, padding: 14, fontSize: 16 }} />)} />
      {errors[name] && <Text style={{ color: colors.danger, marginTop: 4 }}>{errors[name]?.message}</Text>}
    </View>);
  return (
    <SafeAreaView style={{ flex: 1, padding: 24, justifyContent: 'center' }}>
      <Text style={{ fontSize: 24, fontWeight: '800', color: colors.charcoal, marginBottom: 20 }}>Tell us about you</Text>
      {field('full_name', 'Full name')}
      {field('email', 'Email (optional)', 'email-address')}
      {!!err && <Text style={{ color: colors.danger }}>{err}</Text>}
      <Button title="Continue" onPress={save} loading={isSubmitting} />
    </SafeAreaView>
  );
}
