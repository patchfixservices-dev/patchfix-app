import React, { useEffect, useState } from 'react';
import { Text, TextInput, View, Pressable } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button } from '@/components/ui';
import { supabase } from '@/lib/supabase';
import { colors } from '@/lib/theme';
import { registerForPush } from '@/lib/notifications';

export default function Verify() {
  const { phone } = useLocalSearchParams<{ phone: string }>();
  const router = useRouter();
  const [code, setCode] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const [wait, setWait] = useState(30);
  useEffect(() => { if (wait <= 0) return; const t = setTimeout(() => setWait(wait - 1), 1000); return () => clearTimeout(t); }, [wait]);

  const verify = async () => {
    setBusy(true); setErr('');
    const { data, error } = await supabase.auth.verifyOtp({ phone: '+91' + phone, token: code, type: 'sms' });
    setBusy(false);
    if (error || !data.session) return setErr('Invalid or expired OTP. Please try again.');
    const { data: prof } = await supabase.from('profiles').select('full_name').eq('id', data.session.user.id).single();
    registerForPush();
    router.replace(prof?.full_name ? '/(tabs)' : '/(auth)/register');
  };
  const resend = async () => { setWait(30); setErr(''); const { error } = await supabase.auth.signInWithOtp({ phone: '+91' + phone }); if (error) setErr('Could not resend OTP.'); };

  return (
    <SafeAreaView style={{ flex: 1, padding: 24, justifyContent: 'center' }}>
      <Text style={{ fontSize: 24, fontWeight: '800', color: colors.charcoal }}>Verify OTP</Text>
      <Text style={{ color: colors.muted, marginBottom: 16 }}>Enter the 6-digit code sent to +91 {phone}</Text>
      <TextInput value={code} onChangeText={setCode} keyboardType="number-pad" maxLength={6} accessibilityLabel="OTP code" textContentType="oneTimeCode"
        style={{ borderWidth: 1, borderColor: colors.border, backgroundColor: colors.grey, borderRadius: 12, padding: 14, fontSize: 22, letterSpacing: 8, textAlign: 'center' }} />
      {!!err && <Text style={{ color: colors.danger, marginTop: 8 }}>{err}</Text>}
      <Button title="Verify" onPress={verify} loading={busy} disabled={code.length !== 6} style={{ marginTop: 20 }} />
      <Pressable onPress={resend} disabled={wait > 0} style={{ alignSelf: 'center', marginTop: 16 }}>
        <Text style={{ color: wait > 0 ? colors.muted : colors.charcoal, fontWeight: '600' }}>{wait > 0 ? `Resend OTP in ${wait}s` : 'Resend OTP'}</Text>
      </Pressable>
    </SafeAreaView>
  );
}
