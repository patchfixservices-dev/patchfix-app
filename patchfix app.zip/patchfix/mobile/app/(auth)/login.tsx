import React, { useState } from 'react';
import { Text, TextInput, View, KeyboardAvoidingView, Platform } from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Button } from '@/components/ui';
import { supabase } from '@/lib/supabase';
import { colors } from '@/lib/theme';

const schema = z.object({ phone: z.string().regex(/^[6-9][0-9]{9}$/, 'Enter a valid 10-digit mobile number') });

export default function Login() {
  const router = useRouter();
  const [err, setErr] = useState('');
  const { control, handleSubmit, formState: { errors, isSubmitting } } = useForm<{ phone: string }>({ resolver: zodResolver(schema), defaultValues: { phone: '' } });
  const send = handleSubmit(async ({ phone }) => {
    setErr('');
    const { error } = await supabase.auth.signInWithOtp({ phone: '+91' + phone });
    if (error) return setErr('Could not send OTP. Please try again.');
    router.push({ pathname: '/(auth)/verify', params: { phone } });
  });
  return (
    <SafeAreaView style={{ flex: 1 }}>
      <KeyboardAvoidingView style={{ flex: 1, padding: 24, justifyContent: 'center' }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <Image source={require('@/assets/logo.png')} style={{ width: 220, height: 100, alignSelf: 'center' }} contentFit="contain" />
        <Text style={{ fontSize: 24, fontWeight: '800', color: colors.charcoal, marginTop: 24 }}>Login or sign up</Text>
        <Text style={{ color: colors.muted, marginBottom: 16 }}>We will send a one-time password to your mobile number.</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: colors.border, borderRadius: 12, backgroundColor: colors.grey }}>
          <Text style={{ paddingLeft: 14, fontSize: 16, color: colors.charcoal }}>+91</Text>
          <Controller control={control} name="phone" render={({ field }) => (
            <TextInput value={field.value} onChangeText={field.onChange} keyboardType="number-pad" maxLength={10} placeholder="Mobile number" accessibilityLabel="Mobile number"
              style={{ flex: 1, padding: 14, fontSize: 16 }} />)} />
        </View>
        {errors.phone && <Text style={{ color: colors.danger, marginTop: 6 }}>{errors.phone.message}</Text>}
        {!!err && <Text style={{ color: colors.danger, marginTop: 6 }}>{err}</Text>}
        <Button title="Send OTP" onPress={send} loading={isSubmitting} style={{ marginTop: 20 }} />
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}
