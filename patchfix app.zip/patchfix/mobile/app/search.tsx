import React, { useState } from 'react';
import { FlatList, Pressable, Text, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { X } from 'lucide-react-native';
import { useSearch } from '@/lib/api';
import { Empty, ErrorState, Loading, ServiceImage } from '@/components/ui';
import { colors, radius } from '@/lib/theme';
import { inr } from '@/lib/format';

export default function SearchScreen() {
  const router = useRouter();
  const [q, setQ] = useState('');
  const { data, isFetching, isError, refetch } = useSearch(q);
  return (
    <View style={{ flex: 1, padding: 16 }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: colors.grey, borderRadius: radius.md, paddingHorizontal: 12 }}>
        <TextInput autoFocus value={q} onChangeText={setQ} placeholder="Search services, e.g. AC, tap, sofa" accessibilityLabel="Search services" style={{ flex: 1, paddingVertical: 12, fontSize: 16 }} />
        {!!q && <Pressable onPress={() => setQ('')} accessibilityLabel="Clear search"><X size={18} color={colors.muted} /></Pressable>}
      </View>
      {q.trim().length < 2 ? <Empty text="Type at least 2 letters to search all services." /> :
        isFetching ? <Loading /> : isError ? <ErrorState onRetry={refetch} /> :
        <FlatList data={data} keyExtractor={(s) => s.id} keyboardShouldPersistTaps="handled" ListEmptyComponent={<Empty text={`No services found for “${q}”.`} />} contentContainerStyle={{ flexGrow: 1, paddingTop: 12 }}
          renderItem={({ item }) => (
            <Pressable onPress={() => router.push(`/service/${item.slug}`)} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 10 }}>
              <View style={{ width: 64, height: 64, backgroundColor: colors.grey, borderRadius: radius.md, alignItems: 'center', justifyContent: 'center' }}><ServiceImage uri={item.image_url} style={{ width: 48, height: 48 }} /></View>
              <View style={{ marginLeft: 12, flex: 1 }}><Text style={{ color: colors.charcoal, fontWeight: '600' }}>{item.name}</Text><Text style={{ color: colors.muted }}>{item.is_quote_only ? 'Custom quote' : `from ${inr(item.base_price)}`}</Text></View>
            </Pressable>)} />}
    </View>
  );
}
