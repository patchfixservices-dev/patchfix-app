import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { useQueryClient } from '@tanstack/react-query';
import { SafeAreaView } from 'react-native-safe-area-context';
import * as Linking from 'expo-linking';
import { MapPin, Bell, LifeBuoy, FileText, Shield, LogOut, ChevronRight, CalendarCheck } from 'lucide-react-native';
import { useProfile } from '@/lib/api';
import { Button, ErrorState, Loading } from '@/components/ui';
import { supabase } from '@/lib/supabase';
import { colors, radius } from '@/lib/theme';

export default function Profile() {
  const router = useRouter();
  const qc = useQueryClient();
  const { data, isLoading, isError, refetch } = useProfile();
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState('');
  if (isLoading) return <Loading />;
  if (isError || !data) return <ErrorState onRetry={refetch} />;

  const save = async () => {
    const { error } = await supabase.from('profiles').update({ full_name: name.trim() }).eq('id', data.id);
    if (error) return Alert.alert('Could not save', 'Please try again.');
    setEditing(false); qc.invalidateQueries({ queryKey: ['profile'] });
  };
  const logout = async () => { await supabase.auth.signOut(); qc.clear(); router.replace('/(auth)/login'); };
  const row = (I: any, label: string, onPress: () => void) => (
    <Pressable onPress={onPress} accessibilityRole="button" style={{ flexDirection: 'row', alignItems: 'center', paddingVertical: 14, borderBottomWidth: 1, borderColor: colors.border }}>
      <I size={20} color={colors.charcoal} /><Text style={{ flex: 1, marginLeft: 12, color: colors.charcoal, fontSize: 15 }}>{label}</Text><ChevronRight size={18} color={colors.muted} />
    </Pressable>);
  return (
    <SafeAreaView style={{ flex: 1 }} edges={['top']}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <View style={{ backgroundColor: colors.grey, borderRadius: radius.lg, padding: 16 }}>
          {editing ? (
            <>
              <TextInput value={name} onChangeText={setName} placeholder="Full name" accessibilityLabel="Full name" style={{ backgroundColor: colors.white, borderRadius: 10, padding: 12, fontSize: 16 }} />
              <View style={{ flexDirection: 'row', marginTop: 10 }}><Button title="Save" onPress={save} style={{ flex: 1, marginRight: 8 }} /><Button title="Cancel" variant="outline" onPress={() => setEditing(false)} style={{ flex: 1 }} /></View>
            </>
          ) : (
            <>
              <Text style={{ fontSize: 20, fontWeight: '800', color: colors.charcoal }}>{data.full_name ?? 'Your name'}</Text>
              <Text style={{ color: colors.muted, marginTop: 2 }}>{data.phone ?? ''}{data.email ? ` · ${data.email}` : ''}</Text>
              <Pressable onPress={() => { setName(data.full_name ?? ''); setEditing(true); }} style={{ marginTop: 8 }}><Text style={{ color: colors.charcoal, fontWeight: '700', textDecorationLine: 'underline' }}>Edit profile</Text></Pressable>
            </>)}
        </View>
        <View style={{ marginTop: 8 }}>
          {row(CalendarCheck, 'My bookings & payment history', () => router.push('/(tabs)/bookings'))}
          {row(MapPin, 'Saved addresses', () => router.push('/addresses'))}
          {row(Bell, 'Notifications', () => router.push('/notifications'))}
          {row(LifeBuoy, 'Help & Support', () => router.push('/help'))}
          {row(FileText, 'Terms & Conditions', () => Linking.openURL('https://patchfix.in/terms'))}
          {row(Shield, 'Privacy Policy', () => Linking.openURL('https://patchfix.in/privacy'))}
          {row(LogOut, 'Logout', logout)}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
