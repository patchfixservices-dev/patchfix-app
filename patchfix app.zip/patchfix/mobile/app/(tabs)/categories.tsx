import React from 'react';
import { ScrollView, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useCategories } from '@/lib/api';
import { CategoryCard, ErrorState, Loading } from '@/components/ui';
import { colors } from '@/lib/theme';

export default function Categories() {
  const router = useRouter();
  const { data, isLoading, isError, refetch } = useCategories();
  if (isLoading) return <Loading />;
  if (isError) return <ErrorState onRetry={refetch} />;
  return (
    <SafeAreaView style={{ flex: 1 }} edges={['top']}>
      <ScrollView contentContainerStyle={{ padding: 16 }}>
        <Text style={{ fontSize: 24, fontWeight: '800', color: colors.charcoal, marginBottom: 16 }}>All categories</Text>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
          {data!.map((c) => <CategoryCard key={c.id} name={c.name} image={c.image_url} onPress={() => router.push(`/category/${c.slug}`)} />)}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}
