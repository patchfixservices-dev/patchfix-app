import React from 'react';
import { FlatList, Pressable, ScrollView, Text, TextInput, View } from 'react-native';
import { Image } from 'expo-image';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Bell, MapPin, Search, ShieldCheck, Clock, BadgeIndianRupee, Star } from 'lucide-react-native';
import { useAddresses, useCategories, usePopular, useSettings } from '@/lib/api';
import { CategoryCard, Empty, ErrorState, Loading, Section, ServiceImage } from '@/components/ui';
import { colors, radius } from '@/lib/theme';
import { inr } from '@/lib/format';
import { supabase } from '@/lib/supabase';
import { useQuery } from '@tanstack/react-query';

export default function Home() {
  const router = useRouter();
  const cats = useCategories();
  const popular = usePopular();
  const addrs = useAddresses();
  const settings = useSettings();
  const reviews = useQuery({ queryKey: ['home-reviews'], queryFn: async () => {
    const { data } = await supabase.from('reviews').select('rating, comment').eq('is_published', true).order('created_at', { ascending: false }).limit(8);
    return data ?? [];
  } });
  const loc = addrs.data?.[0] ? `${addrs.data[0].label} · ${addrs.data[0].pincode}` : 'Set service location';
  const banner = settings.data?.promo_banner as string | undefined;

  if (cats.isLoading) return <Loading />;
  if (cats.isError) return <ErrorState onRetry={() => cats.refetch()} />;

  return (
    <SafeAreaView style={{ flex: 1 }} edges={['top']}>
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 32 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
          <Image source={require('@/assets/logo.png')} style={{ width: 130, height: 52 }} contentFit="contain" />
          <Pressable onPress={() => router.push('/notifications')} accessibilityLabel="Notifications" accessibilityRole="button" style={{ padding: 8 }}><Bell color={colors.charcoal} /></Pressable>
        </View>
        <Pressable onPress={() => router.push('/addresses')} style={{ flexDirection: 'row', alignItems: 'center', marginTop: 8 }} accessibilityRole="button" accessibilityLabel="Change service location">
          <MapPin size={16} color={colors.charcoal} /><Text style={{ marginLeft: 6, color: colors.charcoal, fontWeight: '600' }}>{loc}</Text>
        </Pressable>
        <Pressable onPress={() => router.push('/search')} accessibilityRole="search" style={{ flexDirection: 'row', alignItems: 'center', backgroundColor: colors.grey, borderRadius: radius.md, padding: 14, marginTop: 14 }}>
          <Search size={18} color={colors.muted} /><Text style={{ marginLeft: 10, color: colors.muted }}>Search for services</Text>
        </Pressable>

        <View style={{ backgroundColor: colors.charcoal, borderRadius: radius.lg, padding: 20, marginTop: 16 }}>
          <Text style={{ color: colors.yellow, fontWeight: '800', fontSize: 20 }}>Trusted by Homes</Text>
          <Text style={{ color: colors.white, marginTop: 6 }}>{banner ?? 'Book verified home service professionals in Coimbatore.'}</Text>
        </View>

        <Section title="Our services">
          <View style={{ flexDirection: 'row', flexWrap: 'wrap' }}>
            {cats.data!.map((c) => <CategoryCard key={c.id} name={c.name} image={c.image_url} onPress={() => router.push(`/category/${c.slug}`)} />)}
          </View>
        </Section>

        <Section title="Popular services">
          {popular.isLoading ? <Loading /> : popular.data?.length ? (
            <FlatList horizontal data={popular.data} keyExtractor={(x) => x.id} showsHorizontalScrollIndicator={false}
              renderItem={({ item }) => (
                <Pressable onPress={() => router.push(`/service/${item.slug}`)} style={{ width: 130, marginRight: 12 }} accessibilityRole="button" accessibilityLabel={item.name}>
                  <View style={{ backgroundColor: colors.grey, borderRadius: radius.lg, height: 110, alignItems: 'center', justifyContent: 'center' }}><ServiceImage uri={item.image_url} style={{ width: '75%', height: '75%' }} /></View>
                  <Text numberOfLines={2} style={{ color: colors.charcoal, marginTop: 6 }}>{item.name}</Text>
                  <Text style={{ color: colors.muted, fontSize: 12 }}>{item.is_quote_only ? 'Get a quote' : `from ${inr(item.base_price)}`}</Text>
                </Pressable>)} />
          ) : <Empty text="Popular services will appear here." />}
        </Section>

        <Section title="Why choose PatchFix?">
          {[[ShieldCheck, 'Verified professionals'], [BadgeIndianRupee, 'Transparent pricing'], [Clock, 'Choose your own time slot']].map(([I, t]: any) => (
            <View key={t} style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 10 }}>
              <View style={{ width: 40, height: 40, borderRadius: 20, backgroundColor: colors.grey, alignItems: 'center', justifyContent: 'center' }}><I size={20} color={colors.charcoal} /></View>
              <Text style={{ marginLeft: 12, color: colors.charcoal, fontSize: 15 }}>{t}</Text>
            </View>))}
        </Section>

        {!!reviews.data?.length && (
          <Section title="Customer reviews">
            {reviews.data.map((r: any, i: number) => (
              <View key={i} style={{ backgroundColor: colors.grey, borderRadius: radius.md, padding: 14, marginBottom: 10 }}>
                <View style={{ flexDirection: 'row' }}>{Array.from({ length: r.rating }).map((_, k) => <Star key={k} size={14} color={colors.yellow} fill={colors.yellow} />)}</View>
                {!!r.comment && <Text style={{ color: colors.charcoal, marginTop: 6 }}>{r.comment}</Text>}
              </View>))}
          </Section>)}
      </ScrollView>
    </SafeAreaView>
  );
}
