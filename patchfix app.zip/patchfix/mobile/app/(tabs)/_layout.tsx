import React from 'react';
import { Tabs, Redirect } from 'expo-router';
import { Home, LayoutGrid, CalendarCheck, User } from 'lucide-react-native';
import { colors } from '@/lib/theme';
import { useSession } from '@/lib/session';

export default function TabsLayout() {
  const { session, loading } = useSession();
  if (!loading && !session) return <Redirect href="/(auth)/login" />;
  const icon = (I: any) => ({ color, size }: { color: string; size: number }) => <I color={color} size={size} />;
  return (
    <Tabs screenOptions={{ headerShown: false, tabBarActiveTintColor: colors.charcoal, tabBarInactiveTintColor: colors.muted,
      tabBarStyle: { height: 62, paddingBottom: 8 }, tabBarActiveBackgroundColor: 'transparent', tabBarLabelStyle: { fontWeight: '600' } }}>
      <Tabs.Screen name="index" options={{ title: 'Home', tabBarIcon: icon(Home) }} />
      <Tabs.Screen name="categories" options={{ title: 'Categories', tabBarIcon: icon(LayoutGrid) }} />
      <Tabs.Screen name="bookings" options={{ title: 'My Bookings', tabBarIcon: icon(CalendarCheck) }} />
      <Tabs.Screen name="profile" options={{ title: 'Profile', tabBarIcon: icon(User) }} />
    </Tabs>
  );
}
