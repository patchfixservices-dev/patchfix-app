import React, { useState } from 'react';
import { FlatList, Pressable, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useBookings } from '@/lib/api';
import { Empty, ErrorState, Loading } from '@/components/ui';
import { colors, radius } from '@/lib/theme';
import { dateLabel, inr, slotLabel } from '@/lib/format';
import { STATUS_LABEL } from '@/lib/types';

const tabs = ['Upcoming', 'Past', 'Cancelled'] as const;
export default function Bookings() {
  const router = useRouter();
  const [tab, setTab] = useState<(typeof tabs)[number]>('Upcoming');
  const { data, isLoading, isError, refetch } = useBookings();
  if (isLoading) return <Loading />;
  if (isError) return <ErrorState onRetry={refetch} />;
  const list = (data ?? []).filter((b) => tab === 'Cancelled' ? b.status === 'cancelled' : tab === 'Past' ? b.status === 'completed' : !['cancelled', 'completed'].includes(b.status));
  return (
    <SafeAreaView style={{ flex: 1 }} edges={['top']}>
      <Text style={{ fontSize: 24, fontWeight: '800', color: colors.charcoal, padding: 16 }}>My Bookings</Text>
      <View style={{ flexDirection: 'row', paddingHorizontal: 16, marginBottom: 8 }}>
        {tabs.map((t) => (
          <Pressable key={t} onPress={() => setTab(t)} accessibilityRole="tab" style={{ marginRight: 10, paddingVertical: 8, paddingHorizontal: 16, borderRadius: 20, backgroundColor: tab === t ? colors.yellow : colors.grey }}>
            <Text style={{ color: colors.charcoal, fontWeight: '700' }}>{t}</Text>
          </Pressable>))}
      </View>
      <FlatList data={list} keyExtractor={(b) => b.id} contentContainerStyle={{ padding: 16, flexGrow: 1 }} onRefresh={refetch} refreshing={false}
        ListEmptyComponent={<Empty text={`No ${tab.toLowerCase()} bookings.`} />}
        renderItem={({ item: b }) => (
          <Pressable onPress={() => router.push(`/booking-detail/${b.id}`)} style={{ backgroundColor: colors.grey, borderRadius: radius.md, padding: 14, marginBottom: 12 }} accessibilityRole="button">
            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
              <Text style={{ fontWeight: '700', color: colors.charcoal }}>{b.reference}</Text>
              <Text style={{ color: colors.charcoal, fontWeight: '600' }}>{STATUS_LABEL[b.status]}</Text>
            </View>
            <Text style={{ color: colors.muted, marginTop: 4 }}>{dateLabel(b.scheduled_date)} · {slotLabel(b.slot)}</Text>
            <Text style={{ color: colors.charcoal, marginTop: 4 }}>{b.is_estimate ? 'Estimate ' : ''}{inr(b.total)}</Text>
          </Pressable>)} />
    </SafeAreaView>
  );
}
