import React from 'react';
import { Pressable, ScrollView, Text, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Check, X, Clock, Star } from 'lucide-react-native';
import { useService } from '@/lib/api';
import { Button, ErrorState, Loading, ServiceImage } from '@/components/ui';
import { colors, radius } from '@/lib/theme';
import { duration, inr } from '@/lib/format';

export default function ServiceDetail() {
  const { slug } = useLocalSearchParams<{ slug: string }>();
  const router = useRouter();
  const { data, isLoading, isError, refetch } = useService(slug);
  if (isLoading) return <Loading />;
  if (isError || !data) return <ErrorState onRetry={refetch} />;
  const { service: s, variants, related, reviews } = data;
  const list = (title: string, items: string[], I: any, c: string) => !items?.length ? null : (
    <View style={{ marginTop: 20 }}>
      <Text style={{ fontSize: 17, fontWeight: '700', color: colors.charcoal, marginBottom: 8 }}>{title}</Text>
      {items.map((t) => <View key={t} style={{ flexDirection: 'row', marginBottom: 6 }}><I size={18} color={c} /><Text style={{ marginLeft: 8, color: colors.charcoal, flex: 1 }}>{t}</Text></View>)}
    </View>);
  const avg = reviews.length ? reviews.reduce((a: number, r: any) => a + r.rating, 0) / reviews.length : 0;
  return (
    <SafeAreaView style={{ flex: 1 }} edges={['bottom']}>
      <Stack.Screen options={{ title: s.name }} />
      <ScrollView contentContainerStyle={{ padding: 16, paddingBottom: 24 }}>
        <View style={{ backgroundColor: colors.grey, borderRadius: radius.xl, height: 240, alignItems: 'center', justifyContent: 'center' }}>
          <ServiceImage uri={s.image_url} style={{ width: '80%', height: '80%' }} />
        </View>
        <Text style={{ fontSize: 24, fontWeight: '800', color: colors.charcoal, marginTop: 16 }}>{s.name}</Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: 6 }}>
          <Clock size={16} color={colors.muted} /><Text style={{ marginLeft: 6, color: colors.muted }}>{duration(s.duration_minutes)}</Text>
          {reviews.length > 0 && <><Star size={16} color={colors.yellow} fill={colors.yellow} style={{ marginLeft: 16 }} /><Text style={{ marginLeft: 4, color: colors.muted }}>{avg.toFixed(1)} ({reviews.length})</Text></>}
        </View>
        <Text style={{ marginTop: 12, color: colors.charcoal, lineHeight: 21 }}>{s.description}</Text>
        {list('Benefits', s.benefits, Check, colors.success)}
        {list("What's included", s.included, Check, colors.success)}
        {list("What's not included", s.not_included, X, colors.danger)}
        {variants.length > 0 && (
          <View style={{ marginTop: 20 }}>
            <Text style={{ fontSize: 17, fontWeight: '700', color: colors.charcoal, marginBottom: 8 }}>Options & add-ons</Text>
            {variants.map((v) => <View key={v.id} style={{ flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 6 }}><Text style={{ color: colors.charcoal }}>{v.name}</Text><Text style={{ color: colors.charcoal }}>+{inr(v.price)}</Text></View>)}
          </View>)}
        {Array.isArray(s.faqs) && s.faqs.length > 0 && (
          <View style={{ marginTop: 20 }}>
            <Text style={{ fontSize: 17, fontWeight: '700', color: colors.charcoal, marginBottom: 8 }}>FAQs</Text>
            {s.faqs.map((f, i) => <View key={i} style={{ marginBottom: 10 }}><Text style={{ fontWeight: '600', color: colors.charcoal }}>{f.q}</Text><Text style={{ color: colors.muted }}>{f.a}</Text></View>)}
          </View>)}
        {reviews.length > 0 && (
          <View style={{ marginTop: 20 }}>
            <Text style={{ fontSize: 17, fontWeight: '700', color: colors.charcoal, marginBottom: 8 }}>Customer reviews</Text>
            {reviews.map((r: any, i: number) => <View key={i} style={{ backgroundColor: colors.grey, borderRadius: radius.md, padding: 12, marginBottom: 8 }}><Text style={{ color: colors.charcoal }}>{'★'.repeat(r.rating)}</Text>{!!r.comment && <Text style={{ color: colors.charcoal, marginTop: 4 }}>{r.comment}</Text>}</View>)}
          </View>)}
        {related.length > 0 && (
          <View style={{ marginTop: 20 }}>
            <Text style={{ fontSize: 17, fontWeight: '700', color: colors.charcoal, marginBottom: 8 }}>Related services</Text>
            <ScrollView horizontal showsHorizontalScrollIndicator={false}>
              {related.map((r) => (
                <Pressable key={r.id} onPress={() => router.push(`/service/${r.slug}`)} style={{ width: 110, marginRight: 10 }} accessibilityRole="button" accessibilityLabel={r.name}>
                  <View style={{ backgroundColor: colors.grey, borderRadius: radius.md, height: 90, alignItems: 'center', justifyContent: 'center' }}><ServiceImage uri={r.image_url} style={{ width: '70%', height: '70%' }} /></View>
                  <Text numberOfLines={2} style={{ fontSize: 12, color: colors.charcoal, marginTop: 4 }}>{r.name}</Text>
                </Pressable>))}
            </ScrollView>
          </View>)}
      </ScrollView>
      <View style={{ flexDirection: 'row', alignItems: 'center', padding: 16, borderTopWidth: 1, borderColor: colors.border, backgroundColor: colors.white }}>
        <View style={{ flex: 1 }}>
          <Text style={{ color: colors.muted, fontSize: 12 }}>{s.is_quote_only ? 'Price' : s.price_is_estimate ? 'Starting estimate' : 'Starting at'}</Text>
          <Text style={{ fontSize: 20, fontWeight: '800', color: colors.charcoal }}>{s.is_quote_only ? 'Custom quote' : inr(s.base_price)}</Text>
        </View>
        <Button title="Book This Service" onPress={() => router.push(`/booking/${s.id}`)} />
      </View>
    </SafeAreaView>
  );
}
