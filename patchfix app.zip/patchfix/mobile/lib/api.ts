import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { supabase } from './supabase';
import type { Address, Booking, BookingFull, Category, Service, Variant } from './types';

const unwrap = <T,>(r: { data: T | null; error: any }): T => {
  if (r.error) throw new Error(r.error.message);
  return r.data as T;
};

export const useCategories = () =>
  useQuery({ queryKey: ['categories'], queryFn: async () =>
    unwrap(await supabase.from('service_categories').select('*').eq('is_active', true).order('sort_order')) as Category[] });

export const useCategoryServices = (slug: string) =>
  useQuery({ queryKey: ['category', slug], queryFn: async () => {
    const cat = unwrap(await supabase.from('service_categories').select('*').eq('slug', slug).single()) as Category;
    const services = unwrap(await supabase.from('services').select('*').eq('category_id', cat.id).eq('is_active', true).order('sort_order')) as Service[];
    return { category: cat, services };
  } });

export const useService = (slug: string) =>
  useQuery({ queryKey: ['service', slug], queryFn: async () => {
    const service = unwrap(await supabase.from('services').select('*').eq('slug', slug).eq('is_active', true).single()) as Service;
    const variants = unwrap(await supabase.from('service_variants').select('*').eq('service_id', service.id).eq('is_active', true)) as Variant[];
    const related = unwrap(await supabase.from('services').select('*').eq('category_id', service.category_id).neq('id', service.id).eq('is_active', true).limit(6)) as Service[];
    const reviews = unwrap(await supabase.from('reviews').select('rating, comment, created_at').eq('service_id', service.id).eq('is_published', true).limit(10)) as any[];
    return { service, variants, related, reviews };
  } });

export const useServiceById = (id: string) =>
  useQuery({ queryKey: ['service-id', id], queryFn: async () => {
    const service = unwrap(await supabase.from('services').select('*').eq('id', id).single()) as Service;
    const variants = unwrap(await supabase.from('service_variants').select('*').eq('service_id', id).eq('is_active', true)) as Variant[];
    return { service, variants };
  } });

export const usePopular = () =>
  useQuery({ queryKey: ['popular'], queryFn: async () =>
    unwrap(await supabase.from('services').select('*').eq('is_active', true).eq('is_popular', true).limit(10)) as Service[] });

export const useSearch = (q: string) =>
  useQuery({ queryKey: ['search', q], enabled: q.trim().length >= 2, queryFn: async () => {
    const term = q.trim().replace(/[%,]/g, '');
    return unwrap(await supabase.from('services').select('*').eq('is_active', true)
      .or(`name.ilike.%${term}%,description.ilike.%${term}%,keywords.cs.{${term.toLowerCase()}}`).limit(40)) as Service[];
  } });

export const useAddresses = () =>
  useQuery({ queryKey: ['addresses'], queryFn: async () =>
    unwrap(await supabase.from('addresses').select('*').order('created_at', { ascending: false })) as Address[] });

export const useSaveAddress = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (a: Omit<Address, 'id' | 'city_id' | 'is_default'>) => {
      const { data: { user } } = await supabase.auth.getUser();
      const { data: city } = await supabase.rpc('check_serviceable', { p_pincode: a.pincode });
      return unwrap(await supabase.from('addresses').insert({ ...a, user_id: user!.id, city_id: city?.[0]?.city_id ?? null }).select().single()) as Address;
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['addresses'] }),
  });
};
export const useDeleteAddress = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (id: string) => { const { error } = await supabase.from('addresses').delete().eq('id', id); if (error) throw new Error(error.message); },
    onSuccess: () => qc.invalidateQueries({ queryKey: ['addresses'] }),
  });
};

export const useSlots = (cityId: string | null | undefined, date: string) =>
  useQuery({ queryKey: ['slots', cityId, date], enabled: !!cityId, queryFn: async () =>
    unwrap(await supabase.rpc('available_slots', { p_city: cityId, p_date: date })) as { slot: string; remaining: number }[] });

export const useSettings = () =>
  useQuery({ queryKey: ['settings'], queryFn: async () => {
    const rows = unwrap(await supabase.from('app_settings').select('key,value')) as { key: string; value: any }[];
    return Object.fromEntries(rows.map((r) => [r.key, r.value])) as Record<string, any>;
  } });

export const useBookings = () =>
  useQuery({ queryKey: ['bookings'], queryFn: async () =>
    unwrap(await supabase.from('bookings').select('*').order('created_at', { ascending: false })) as Booking[] });

export const useBooking = (id: string) =>
  useQuery({ queryKey: ['booking', id], queryFn: async () =>
    unwrap(await supabase.from('bookings').select('*, booking_items(*), booking_status_history(*), addresses(*)').eq('id', id).single()) as BookingFull });

export const useCancelBooking = () => {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (v: { id: string; reason?: string }) =>
      unwrap(await supabase.rpc('cancel_booking', { p_booking_id: v.id, p_reason: v.reason ?? null })),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ['bookings'] }); qc.invalidateQueries({ queryKey: ['booking'] }); },
  });
};

export const useNotifications = () =>
  useQuery({ queryKey: ['notifications'], queryFn: async () =>
    unwrap(await supabase.from('notifications').select('*').order('created_at', { ascending: false }).limit(50)) as any[] });

export const useProfile = () =>
  useQuery({ queryKey: ['profile'], queryFn: async () => {
    const { data: { user } } = await supabase.auth.getUser();
    return unwrap(await supabase.from('profiles').select('*').eq('id', user!.id).single()) as { id: string; full_name: string | null; phone: string | null; email: string | null };
  } });

export const ERROR_TEXT: Record<string, string> = {
  area_not_serviceable: 'Sorry, we do not serve this PIN code yet.',
  slot_full: 'That time slot just filled up. Please pick another.',
  invalid_slot: 'That time slot is not available.',
  date_in_past: 'Please choose a future date.',
  invalid_contact: 'Please check your name and phone number.',
  cancellation_window_closed: 'This booking is too close to its slot to cancel online. Please contact support.',
  cannot_cancel: 'This booking can no longer be cancelled.',
};
export const friendly = (e: unknown) => {
  const m = String((e as Error)?.message ?? e);
  const k = Object.keys(ERROR_TEXT).find((x) => m.includes(x));
  return k ? ERROR_TEXT[k] : 'Something went wrong. Please try again.';
};
