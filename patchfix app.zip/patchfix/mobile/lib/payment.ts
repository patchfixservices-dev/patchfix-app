import { supabase } from './supabase';

export type PayResult = 'launched' | 'cancelled' | 'unavailable';

/**
 * Online payment. The order is created server-side; the client callback is NOT trusted:
 * the booking only becomes "paid" when the verified Razorpay webhook arrives.
 * react-native-razorpay is a native module -> works in the EAS APK/dev build, NOT in Expo Go.
 */
export async function payOnline(booking: { id: string; reference: string }, user: { name: string; phone: string; email?: string | null }): Promise<PayResult> {
  const { data, error } = await supabase.functions.invoke('razorpay-create-order', { body: { booking_id: booking.id } });
  if (error || !data?.order_id) throw new Error('payment_order_failed');
  let Razorpay: any;
  try { Razorpay = require('react-native-razorpay').default; } catch { return 'unavailable'; }
  if (!Razorpay?.open) return 'unavailable';
  try {
    await Razorpay.open({
      key: data.key_id, order_id: data.order_id, amount: data.amount, currency: data.currency,
      name: 'PatchFix', description: `Booking ${booking.reference}`, theme: { color: '#FDBD00' },
      prefill: { name: user.name, contact: user.phone, email: user.email ?? '' },
    });
    return 'launched';
  } catch {
    return 'cancelled';
  }
}
