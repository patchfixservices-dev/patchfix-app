export const colors = {
  charcoal: '#34383D',
  yellow: '#FDBD00',
  white: '#FFFFFF',
  grey: '#F7F8FA',
  muted: '#777777',
  border: '#E8EAED',
  danger: '#C62828',
  success: '#2E7D32',
};
export const radius = { sm: 8, md: 12, lg: 16, xl: 24 };
export const space = { xs: 4, sm: 8, md: 12, lg: 16, xl: 24, xxl: 32 };
export const font = { h1: 24, h2: 20, h3: 16, body: 14, small: 12 };
