export type Category = { id: string; slug: string; name: string; image_url: string | null; sort_order: number };
export type Service = {
  id: string; category_id: string; slug: string; group_name: string | null; name: string; description: string | null;
  benefits: string[]; included: string[]; not_included: string[]; faqs: { q: string; a: string }[];
  duration_minutes: number; base_price: number; is_quote_only: boolean; price_is_estimate: boolean;
  image_url: string | null; is_popular: boolean; is_featured: boolean; keywords: string[];
};
export type Variant = { id: string; service_id: string; name: string; price: number; is_addon: boolean };
export type Address = {
  id: string; label: string; line1: string; line2: string | null; landmark: string | null;
  pincode: string; city_id: string | null; latitude: number | null; longitude: number | null; is_default: boolean;
};
export type Booking = {
  id: string; reference: string; scheduled_date: string; slot: string; status: string; payment_method: 'online' | 'cash';
  payment_status: string; total: number; subtotal: number; fees: number; tax: number; discount: number; is_estimate: boolean;
  created_at: string; customer_name: string; notes: string | null;
};
export type BookingFull = Booking & {
  booking_items: { id: string; name: string; unit_price: number; quantity: number }[];
  booking_status_history: { id: string; status: string; created_at: string }[];
  addresses: Address | null;
};
export const STATUS_LABEL: Record<string, string> = {
  received: 'Booking Received', confirmed: 'Confirmed', assigned: 'Professional Assigned',
  in_progress: 'Service In Progress', completed: 'Completed', cancelled: 'Cancelled',
};
export const PAYMENT_LABEL: Record<string, string> = {
  pending: 'Pending', paid: 'Paid', failed: 'Failed', refunded: 'Refunded',
  cash_pending: 'Cash Collection Pending', cash_collected: 'Cash Collected',
};
