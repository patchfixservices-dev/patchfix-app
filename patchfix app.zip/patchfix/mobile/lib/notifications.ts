import * as Device from 'expo-device';
import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';
import { Platform } from 'react-native';
import { supabase } from './supabase';

Notifications.setNotificationHandler({
  handleNotification: async () => ({ shouldShowBanner: true, shouldShowList: true, shouldPlaySound: false, shouldSetBadge: false }),
});

/** Registers for Android push. Requires FCM credentials uploaded to EAS (see README). Returns null if unavailable. */
export async function registerForPush(): Promise<string | null> {
  try {
    if (!Device.isDevice) return null;
    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('default', {
        name: 'PatchFix', importance: Notifications.AndroidImportance.HIGH, lightColor: '#FDBD00',
      });
    }
    const { status: existing } = await Notifications.getPermissionsAsync();
    const status = existing === 'granted' ? existing : (await Notifications.requestPermissionsAsync()).status;
    if (status !== 'granted') return null;
    const projectId = (Constants.expoConfig?.extra as any)?.eas?.projectId;
    if (!projectId) return null;
    const token = (await Notifications.getExpoPushTokenAsync({ projectId })).data;
    const { data: { user } } = await supabase.auth.getUser();
    if (user) await supabase.from('profiles').update({ expo_push_token: token }).eq('id', user.id);
    return token;
  } catch {
    return null; // Expo Go / missing credentials: app keeps working with in-app notifications only
  }
}
