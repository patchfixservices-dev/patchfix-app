import React from 'react';
import { ActivityIndicator, Pressable, StyleSheet, Text, View, ViewStyle } from 'react-native';
import { Image } from 'expo-image';
import { colors, font, radius, space } from '@/lib/theme';

export function Button({ title, onPress, disabled, loading, variant = 'primary', style }:
  { title: string; onPress: () => void; disabled?: boolean; loading?: boolean; variant?: 'primary' | 'outline'; style?: ViewStyle }) {
  const off = disabled || loading;
  return (
    <Pressable accessibilityRole="button" accessibilityLabel={title} disabled={off} onPress={onPress}
      style={({ pressed }) => [s.btn, variant === 'outline' && s.btnOutline, off && { opacity: 0.5 }, pressed && { opacity: 0.8 }, style]}>
      {loading ? <ActivityIndicator color={colors.charcoal} /> : <Text style={[s.btnText]}>{title}</Text>}
    </Pressable>
  );
}

export const Loading = () => <View style={s.center}><ActivityIndicator size="large" color={colors.yellow} /></View>;
export const Empty = ({ text }: { text: string }) => <View style={s.center}><Text style={{ color: colors.muted, textAlign: 'center' }}>{text}</Text></View>;
export const ErrorState = ({ onRetry, text = 'Could not load. Check your connection.' }: { onRetry: () => void; text?: string }) => (
  <View style={s.center}><Text style={{ color: colors.charcoal, marginBottom: space.md, textAlign: 'center' }}>{text}</Text><Button title="Retry" onPress={onRetry} variant="outline" /></View>
);

/** Photograph tile with branded fallback when image_url is missing/broken. */
export function ServiceImage({ uri, style }: { uri: string | null; style?: any }) {
  const [failed, setFailed] = React.useState(false);
  if (!uri || failed) {
    return <View style={[style, s.fallback]}><Text style={{ color: colors.muted, fontSize: font.small }}>Photo coming soon</Text></View>;
  }
  return <Image source={{ uri }} style={style} contentFit="contain" transition={150} onError={() => setFailed(true)} accessibilityIgnoresInvertColors />;
}

export function CategoryCard({ name, image, onPress }: { name: string; image: string | null; onPress: () => void }) {
  return (
    <Pressable onPress={onPress} accessibilityRole="button" accessibilityLabel={name} style={({ pressed }) => [s.catWrap, pressed && { opacity: 0.7 }]}>
      <View style={s.catImgBox}><ServiceImage uri={image} style={{ width: '70%', height: '70%' }} /></View>
      <Text style={s.catLabel} numberOfLines={2}>{name}</Text>
    </Pressable>
  );
}

export function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return <View style={{ marginTop: space.xl }}><Text style={s.h2}>{title}</Text>{children}</View>;
}

export const s = StyleSheet.create({
  btn: { backgroundColor: colors.yellow, borderRadius: radius.md, paddingVertical: 14, paddingHorizontal: space.xl, alignItems: 'center', justifyContent: 'center', minHeight: 48 },
  btnOutline: { backgroundColor: colors.white, borderWidth: 1.5, borderColor: colors.charcoal },
  btnText: { color: colors.charcoal, fontWeight: '700', fontSize: font.h3 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: space.xl },
  fallback: { backgroundColor: colors.grey, alignItems: 'center', justifyContent: 'center', borderRadius: radius.md },
  catWrap: { flex: 1, alignItems: 'center', marginBottom: space.lg, maxWidth: '33.3%', paddingHorizontal: 6 },
  catImgBox: { width: '100%', aspectRatio: 1.15, backgroundColor: colors.grey, borderRadius: radius.lg, alignItems: 'center', justifyContent: 'center' },
  catLabel: { marginTop: space.sm, textAlign: 'center', color: colors.charcoal, fontSize: font.body },
  h2: { fontSize: font.h2, fontWeight: '700', color: colors.charcoal, marginBottom: space.md },
});
