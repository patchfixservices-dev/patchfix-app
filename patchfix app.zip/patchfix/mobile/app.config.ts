import { ExpoConfig, ConfigContext } from 'expo/config';

// Android-only. No iOS configuration is defined anywhere in this project.
export default ({ config }: ConfigContext): ExpoConfig => ({
  ...config,
  name: 'PatchFix',
  slug: 'patchfix',
  version: '1.0.0',
  orientation: 'portrait',
  scheme: 'patchfix',
  platforms: ['android'],
  userInterfaceStyle: 'light',
  icon: './assets/icon.png',
  splash: { image: './assets/splash.png', resizeMode: 'contain', backgroundColor: '#FFFFFF' },
  android: {
    package: 'com.patchfix.app',
    versionCode: 1,
    adaptiveIcon: { foregroundImage: './assets/adaptive-icon.png', backgroundColor: '#FFFFFF' },
    permissions: [
      'ACCESS_COARSE_LOCATION',
      'ACCESS_FINE_LOCATION',
      'CAMERA',
      'READ_MEDIA_IMAGES',
      'POST_NOTIFICATIONS',
      'INTERNET',
      'VIBRATE',
    ],
    blockedPermissions: ['android.permission.RECORD_AUDIO', 'android.permission.READ_EXTERNAL_STORAGE', 'android.permission.WRITE_EXTERNAL_STORAGE'],
    config: { googleMaps: { apiKey: process.env.GOOGLE_MAPS_API_KEY ?? '' } },
  },
  plugins: [
    'expo-router',
    ['expo-notifications', { icon: './assets/notification-icon.png', color: '#FDBD00' }],
    ['expo-location', { locationWhenInUsePermission: 'PatchFix uses your location to find your service address.' }],
    ['expo-image-picker', { photosPermission: 'Upload photos of the issue.', cameraPermission: 'Take photos of the issue.' }],
  ],
  experiments: { typedRoutes: false },
  extra: {
    supabaseUrl: process.env.EXPO_PUBLIC_SUPABASE_URL,
    supabaseAnonKey: process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY,
    eas: { projectId: process.env.EAS_PROJECT_ID ?? '' },
  },
});
