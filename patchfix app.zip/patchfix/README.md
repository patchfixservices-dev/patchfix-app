# PatchFix — Android app + Admin dashboard + Supabase backend

Android-only customer app (React Native · Expo · TypeScript), responsive web admin (Next.js), Supabase backend.
App name **PatchFix** · Android application ID **`com.patchfix.app`** · No iOS project, assets or build config exists.

```
patchfix/
  mobile/     Expo Router app (Android only)      app.config.ts, eas.json
  admin/      Next.js + Tailwind admin dashboard
  supabase/   migrations (schema, RLS, RPCs, seed), Edge Functions
  docs/       IMAGES.md (service photo checklist), STATUS.md (what is done / not tested)
```

> **Status honesty:** this code was written but **not compiled or run** (no network in the build sandbox). Expect to fix small
> version/type issues on first `npm install`/`typecheck`. See `docs/STATUS.md` for the checklist.

## 1. Prerequisites
Node 20+, `npm i -g eas-cli supabase`, an Expo account (`eas login`), a Supabase project, Android Studio (emulator) and/or an Android phone.

## 2. Supabase setup
```bash
cd patchfix
supabase login
supabase link --project-ref YOUR_PROJECT_REF
supabase db push                       # runs supabase/migrations/* (schema, RLS, functions, seed, Coimbatore)
```
In the Supabase dashboard:
1. **Authentication → Providers → Phone**: enable and configure an SMS provider (Twilio / MessageBird / Vonage). OTP login will not work until this is done. For development you can add test numbers + fixed OTPs there.
2. **Create the first admin**: Authentication → Users → *Add user* (email + password), then in SQL editor:
   ```sql
   insert into user_roles(user_id, role) select id, 'admin' from auth.users where email = 'you@example.com';
   ```
3. Edge Function secrets and deploy:
   ```bash
   cp supabase/.env.example supabase/.env     # fill Razorpay TEST keys + a random PUSH_WEBHOOK_SECRET
   supabase secrets set --env-file supabase/.env
   supabase functions deploy razorpay-create-order
   supabase functions deploy razorpay-webhook --no-verify-jwt
   supabase functions deploy send-push --no-verify-jwt
   ```
4. **Razorpay**: Dashboard → Settings → Webhooks → URL `https://YOUR_REF.functions.supabase.co/razorpay-webhook`, secret = `RAZORPAY_WEBHOOK_SECRET`, events `payment.captured`, `payment.failed`, `order.paid`, `refund.processed`. Use **test mode** first.
5. **Push**: Database → Webhooks → create on table `notifications` (INSERT) → Supabase Edge Function `send-push`, add HTTP header `x-webhook-secret: <PUSH_WEBHOOK_SECRET>`.
6. Edit business settings in table `app_settings` (tax %, slots, slot capacity, cancellation cutoff hours, support phone/email, `promo_banner`). Seed tax is 18% and prices are **demo estimates**; confirm before launch.

## 3. Mobile app (Android)
```bash
cd mobile
cp .env.example .env            # fill Supabase URL/anon key + Google Maps Android key
npm install
npx expo install --fix          # aligns package versions with your Expo SDK
npm run typecheck
```
**Preview in Expo Go (Android phone or emulator):** `npx expo start --android` (or scan the QR in Expo Go).
Works for browsing, auth, booking, cash payment. Expo Go **cannot** run Razorpay (native module) or reliable push — use the APK below for those.

### Generate and install the APK
```bash
cd mobile
eas login
eas init                        # creates the EAS project; copy the project ID into .env as EAS_PROJECT_ID
eas secret:create --scope project --name EXPO_PUBLIC_SUPABASE_URL      --value "https://YOUR_REF.supabase.co"
eas secret:create --scope project --name EXPO_PUBLIC_SUPABASE_ANON_KEY --value "YOUR_ANON_KEY"
eas secret:create --scope project --name GOOGLE_MAPS_API_KEY           --value "YOUR_MAPS_KEY"
eas secret:create --scope project --name EAS_PROJECT_ID                --value "YOUR_EAS_PROJECT_ID"

eas build --platform android --profile preview     # builds an installable .apk in the cloud
```
When it finishes, open the build URL on your phone (or scan its QR) and install the APK, or download it and run:
```bash
adb install path/to/patchfix.apk          # emulator or USB-connected phone
```
(Allow "install unknown apps" on the phone if prompted.)

### Production AAB for Google Play (later)
```bash
eas build --platform android --profile production  # app-bundle (.aab), versionCode auto-increments
eas submit --platform android --profile production # after creating the Play Console app + service-account key
```
Push notifications need FCM: create a Firebase project with Android package `com.patchfix.app`, then `eas credentials` → Android → upload FCM V1 service-account key.

### Google Maps key
Google Cloud Console → enable **Maps SDK for Android** → create an API key restricted to package `com.patchfix.app` and your build's SHA-1 (`eas credentials` shows it). Address search uses the device geocoder (no Places key needed).

## 4. Admin dashboard
```bash
cd admin
cp .env.example .env.local
npm install
npm run dev        # http://localhost:3001 ; sign in with the admin user from step 2
npm run build      # deploy to Vercel/any Node host; set the two NEXT_PUBLIC_* env vars
```
All permissions are enforced by Supabase RLS (`is_staff()`), not by the UI.

## 5. Service photographs
The app never uses emoji/icons for services. Every service has an `image_url`; until set it shows a neutral "Photo coming soon" tile.
Upload photos from **Admin → Services** or follow `docs/IMAGES.md` (bucket `service-images`). Source licensed, realistic photos — none are bundled.

## 6. Testing checklist (do before launch)
See `docs/STATUS.md`. At minimum: OTP login on a real phone, booking in/out of a serviced PIN, two users racing for the last slot, Razorpay **test** payment + webhook replay (should be idempotent), cash collection by staff only, RLS checks with customer vs admin accounts, run on a low-end Android device and an emulator.
