import { createClient } from '@supabase/supabase-js';
export const supabase = createClient(process.env.NEXT_PUBLIC_SUPABASE_URL ?? '', process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? '');
export const inr = (n: number) => '₹' + Number(n).toLocaleString('en-IN', { maximumFractionDigits: 0 });
export const STATUSES = ['received', 'confirmed', 'assigned', 'in_progress', 'completed', 'cancelled'] as const;
export const STATUS_LABEL: Record<string, string> = { received: 'Booking Received', confirmed: 'Confirmed', assigned: 'Professional Assigned', in_progress: 'Service In Progress', completed: 'Completed', cancelled: 'Cancelled' };
