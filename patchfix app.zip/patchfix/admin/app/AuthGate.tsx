'use client';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';

const nav = [['overview', 'Overview'], ['bookings', 'Bookings'], ['services', 'Services'], ['cities', 'Cities & PIN codes'], ['payments', 'Payments'], ['coupons', 'Coupons'], ['reviews', 'Reviews'], ['customers', 'Customers']];

export default function AuthGate({ children }: { children: React.ReactNode }) {
  const router = useRouter(); const path = usePathname();
  const [ok, setOk] = useState(false); const [open, setOpen] = useState(false);
  useEffect(() => {
    supabase.auth.getSession().then(async ({ data }) => {
      if (!data.session) return router.replace('/login');
      const { data: staff } = await supabase.rpc('is_staff'); // server-side check; UI hiding is not security
      if (!staff) { await supabase.auth.signOut(); return router.replace('/login'); }
      setOk(true);
    });
  }, [router]);
  if (!ok) return <p className="p-6 text-slate2">Loading…</p>;
  return (
    <div className="min-h-screen md:flex">
      <header className="flex items-center justify-between bg-charcoal p-3 text-white md:hidden">
        <b>PatchFix <span className="text-gold">Admin</span></b><button onClick={() => setOpen(!open)} className="rounded border border-white/40 px-2 py-1 text-sm">Menu</button>
      </header>
      <aside className={`${open ? 'block' : 'hidden'} w-full bg-charcoal p-4 text-white md:block md:w-56 md:min-h-screen`}>
        <p className="mb-4 hidden text-lg font-extrabold md:block">PatchFix <span className="text-gold">Admin</span></p>
        <nav className="space-y-1">
          {nav.map(([h, l]) => <Link key={h} href={`/${h}`} onClick={() => setOpen(false)} className={`block rounded-lg px-3 py-2 text-sm ${path.startsWith('/' + h) ? 'bg-gold text-charcoal font-semibold' : 'hover:bg-white/10'}`}>{l}</Link>)}
          <button className="mt-4 w-full rounded-lg border border-white/30 px-3 py-2 text-left text-sm" onClick={async () => { await supabase.auth.signOut(); router.replace('/login'); }}>Sign out</button>
        </nav>
      </aside>
      <main className="flex-1 overflow-x-auto p-4 md:p-6">{children}</main>
    </div>
  );
}
