'use client';
import { useCallback, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

export default function Cities() {
  const [cities, setCities] = useState<any[]>([]); const [areas, setAreas] = useState<any[]>([]); const [err, setErr] = useState('');
  const [name, setName] = useState(''); const [state, setState] = useState('Tamil Nadu'); const [pin, setPin] = useState(''); const [pinCity, setPinCity] = useState('');
  const load = useCallback(async () => {
    const [c, a] = await Promise.all([supabase.from('cities').select('*').order('name'), supabase.from('service_areas').select('*').order('pincode')]);
    if (c.error) return setErr(c.error.message);
    setCities(c.data ?? []); setAreas(a.data ?? []);
  }, []);
  useEffect(() => { load(); }, [load]);
  const run = async (p: PromiseLike<{ error: any }>) => { const { error } = await p; if (error) alert(error.message); load(); };
  return (<>
    <h1 className="mb-4 text-2xl font-extrabold">Cities & PIN codes</h1>{err && <p className="text-red-700">{err}</p>}
    <div className="card mb-4 flex flex-wrap gap-2"><input className="inp" placeholder="City" value={name} onChange={(e) => setName(e.target.value)} /><input className="inp" placeholder="State" value={state} onChange={(e) => setState(e.target.value)} />
      <button className="btn" disabled={!name} onClick={() => { run(supabase.from('cities').insert({ name, state, is_active: false })); setName(''); }}>Add city</button></div>
    {cities.map((c) => (
      <div key={c.id} className="card mb-3">
        <div className="flex flex-wrap items-center gap-3"><h2 className="text-lg font-bold">{c.name}, {c.state}</h2>
          <label className="text-sm"><input type="checkbox" checked={c.is_active} onChange={(e) => run(supabase.from('cities').update({ is_active: e.target.checked }).eq('id', c.id))} /> Active</label>
          <label className="text-sm">Price adjustment % <input type="number" className="inp w-20" defaultValue={c.price_adjustment_pct} onBlur={(e) => run(supabase.from('cities').update({ price_adjustment_pct: Number(e.target.value) }).eq('id', c.id))} /></label></div>
        <div className="mt-2 flex flex-wrap gap-2">{areas.filter((a) => a.city_id === c.id).map((a) => (
          <span key={a.id} className={`rounded-full border px-3 py-1 text-sm ${a.is_active ? 'bg-gold/30' : 'opacity-50'}`}>{a.pincode}{a.area_name ? ` · ${a.area_name}` : ''}
            <button className="ml-2 text-xs underline" onClick={() => run(supabase.from('service_areas').update({ is_active: !a.is_active }).eq('id', a.id))}>{a.is_active ? 'disable' : 'enable'}</button></span>))}</div>
        <div className="mt-3 flex gap-2"><input className="inp" placeholder="Add PIN code" maxLength={6} value={pinCity === c.id ? pin : ''} onChange={(e) => { setPinCity(c.id); setPin(e.target.value); }} />
          <button className="btn-o" disabled={!/^[1-9][0-9]{5}$/.test(pin) || pinCity !== c.id} onClick={() => { run(supabase.from('service_areas').insert({ city_id: c.id, pincode: pin })); setPin(''); }}>Add</button></div>
      </div>))}
  </>);
}
