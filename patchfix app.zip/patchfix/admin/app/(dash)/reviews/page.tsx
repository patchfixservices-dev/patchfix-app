'use client';
import { useCallback, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

export default function Reviews() {
  const [rows, setRows] = useState<any[]>([]); const [err, setErr] = useState('');
  const load = useCallback(async () => { const { data, error } = await supabase.from('reviews').select('*, services(name)').order('created_at', { ascending: false }); error ? setErr(error.message) : setRows(data ?? []); }, []);
  useEffect(() => { load(); }, [load]);
  return (<>
    <h1 className="mb-4 text-2xl font-extrabold">Reviews</h1>{err && <p className="text-red-700">{err}</p>}
    {rows.map((r) => <div key={r.id} className="card mb-3 flex items-start justify-between gap-4"><div><p className="font-semibold">{r.services?.name} · {'★'.repeat(r.rating)}</p><p className="text-sm">{r.comment}</p></div>
      <button className="btn-o" onClick={async () => { await supabase.from('reviews').update({ is_published: !r.is_published }).eq('id', r.id); load(); }}>{r.is_published ? 'Unpublish' : 'Publish'}</button></div>)}
    {!rows.length && <p className="text-slate2">No reviews submitted yet.</p>}
  </>);
}
