'use client';
import { useCallback, useEffect, useState } from 'react';
import { inr, STATUSES, STATUS_LABEL, supabase } from '@/lib/supabase';

export default function Bookings() {
  const [rows, setRows] = useState<any[]>([]); const [pros, setPros] = useState<any[]>([]); const [err, setErr] = useState('');
  const [q, setQ] = useState(''); const [status, setStatus] = useState(''); const [pay, setPay] = useState(''); const [date, setDate] = useState('');
  const load = useCallback(async () => {
    setErr('');
    let query = supabase.from('bookings').select('*, cities(name), booking_items(name,quantity), booking_assignments(professional_id)').order('created_at', { ascending: false }).limit(200);
    if (q) query = query.ilike('reference', `%${q.replace(/[%,]/g, '')}%`);
    if (status) query = query.eq('status', status);
    if (pay) query = query.eq('payment_status', pay);
    if (date) query = query.eq('scheduled_date', date);
    const [b, p] = await Promise.all([query, supabase.from('professionals').select('id,full_name').eq('is_active', true)]);
    if (b.error) return setErr(b.error.message);
    setRows(b.data ?? []); setPros(p.data ?? []);
  }, [q, status, pay, date]);
  useEffect(() => { load(); }, [load]);

  const setStatusFor = async (id: string, s: string) => { const { error } = await supabase.from('bookings').update({ status: s }).eq('id', id); if (error) alert(error.message); load(); };
  const assign = async (id: string, pid: string) => {
    if (!pid) return;
    const { data: { user } } = await supabase.auth.getUser();
    const { error } = await supabase.from('booking_assignments').upsert({ booking_id: id, professional_id: pid, assigned_by: user!.id }, { onConflict: 'booking_id' });
    if (error) return alert(error.message);
    await supabase.from('bookings').update({ status: 'assigned' }).eq('id', id); load();
  };
  const cash = async (id: string) => { const { error } = await supabase.rpc('mark_cash_collected', { p_booking_id: id }); if (error) alert(error.message); load(); };

  return (<>
    <h1 className="mb-4 text-2xl font-extrabold">Bookings</h1>
    <div className="mb-4 flex flex-wrap gap-2">
      <input className="inp" placeholder="Booking ID (PF-…)" value={q} onChange={(e) => setQ(e.target.value)} />
      <select className="inp" value={status} onChange={(e) => setStatus(e.target.value)}><option value="">All statuses</option>{STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}</select>
      <select className="inp" value={pay} onChange={(e) => setPay(e.target.value)}><option value="">All payments</option>{['pending', 'paid', 'failed', 'refunded', 'cash_pending', 'cash_collected'].map((s) => <option key={s}>{s}</option>)}</select>
      <input type="date" className="inp" value={date} onChange={(e) => setDate(e.target.value)} />
    </div>
    {err && <p className="text-red-700">{err}</p>}
    <div className="card overflow-x-auto"><table className="w-full"><thead><tr><th>Ref</th><th>Customer</th><th>Service</th><th>City</th><th>When</th><th>Total</th><th>Payment</th><th>Status</th><th>Assign</th></tr></thead><tbody>
      {rows.map((b) => (<tr key={b.id}>
        <td className="font-semibold">{b.reference}</td><td>{b.customer_name}<br /><span className="text-slate2">{b.customer_phone}</span></td>
        <td>{b.booking_items?.map((i: any) => `${i.name}×${i.quantity}`).join(', ')}</td><td>{b.cities?.name}</td><td>{b.scheduled_date}<br />{b.slot}</td><td>{inr(b.total)}</td>
        <td>{b.payment_status}{b.payment_status === 'cash_pending' && b.status === 'completed' && <button className="btn-o ml-2" onClick={() => cash(b.id)}>Mark collected</button>}</td>
        <td><select className="inp" value={b.status} onChange={(e) => setStatusFor(b.id, e.target.value)}>{STATUSES.map((s) => <option key={s} value={s}>{STATUS_LABEL[s]}</option>)}</select></td>
        <td><select className="inp" value={b.booking_assignments?.[0]?.professional_id ?? ''} onChange={(e) => assign(b.id, e.target.value)}><option value="">Unassigned</option>{pros.map((p) => <option key={p.id} value={p.id}>{p.full_name}</option>)}</select></td>
      </tr>))}
      {!rows.length && <tr><td colSpan={9} className="text-slate2">No bookings found.</td></tr>}
    </tbody></table></div>
  </>);
}
