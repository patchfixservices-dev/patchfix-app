'use client';
import { useEffect, useState } from 'react';
import { inr, supabase } from '@/lib/supabase';

export default function Payments() {
  const [rows, setRows] = useState<any[]>([]); const [err, setErr] = useState('');
  useEffect(() => { supabase.from('payments').select('*, bookings(reference,customer_name)').order('created_at', { ascending: false }).limit(500).then(({ data, error }) => error ? setErr(error.message) : setRows(data ?? [])); }, []);
  const exportCsv = () => {
    const head = 'booking,customer,method,status,amount,razorpay_payment_id,created_at';
    const body = rows.map((r) => [r.bookings?.reference, r.bookings?.customer_name, r.method, r.status, r.amount, r.razorpay_payment_id ?? '', r.created_at].map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`).join(','));
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([[head, ...body].join('\n')], { type: 'text/csv' })); a.download = 'patchfix-payments.csv'; a.click();
  };
  return (<>
    <div className="mb-4 flex items-center justify-between"><h1 className="text-2xl font-extrabold">Payments</h1><button className="btn" onClick={exportCsv}>Export CSV</button></div>{err && <p className="text-red-700">{err}</p>}
    <div className="card overflow-x-auto"><table className="w-full"><thead><tr><th>Booking</th><th>Customer</th><th>Method</th><th>Status</th><th>Amount</th><th>Razorpay ID</th><th>Date</th></tr></thead><tbody>
      {rows.map((r) => <tr key={r.id}><td>{r.bookings?.reference}</td><td>{r.bookings?.customer_name}</td><td>{r.method}</td><td>{r.status}</td><td>{inr(r.amount)}</td><td className="text-xs">{r.razorpay_payment_id ?? '—'}</td><td>{new Date(r.created_at).toLocaleString('en-IN')}</td></tr>)}
    </tbody></table></div>
  </>);
}
