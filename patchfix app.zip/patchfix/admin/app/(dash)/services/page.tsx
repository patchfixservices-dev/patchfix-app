'use client';
import { useCallback, useEffect, useState } from 'react';
import { inr, supabase } from '@/lib/supabase';

export default function Services() {
  const [rows, setRows] = useState<any[]>([]); const [cats, setCats] = useState<any[]>([]); const [err, setErr] = useState(''); const [filter, setFilter] = useState('');
  const load = useCallback(async () => {
    const [s, c] = await Promise.all([supabase.from('services').select('*, service_categories(name)').order('name'), supabase.from('service_categories').select('id,name').order('sort_order')]);
    if (s.error) return setErr(s.error.message);
    setRows(s.data ?? []); setCats(c.data ?? []);
  }, []);
  useEffect(() => { load(); }, [load]);
  const patch = async (id: string, v: Record<string, unknown>) => { const { error } = await supabase.from('services').update(v).eq('id', id); if (error) alert(error.message); else load(); };
  const upload = async (s: any, file?: File) => {
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type) || file.size > 2 * 1024 * 1024) return alert('Use a JPG/PNG/WebP under 2 MB.');
    const path = `${s.slug}-${Date.now()}.${file.type.split('/')[1]}`;
    const { error } = await supabase.storage.from('service-images').upload(path, file, { upsert: true });
    if (error) return alert(error.message);
    patch(s.id, { image_url: supabase.storage.from('service-images').getPublicUrl(path).data.publicUrl });
  };
  const add = async () => {
    const name = prompt('Service name?'); if (!name) return;
    const category_id = cats[0]?.id; const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    const { error } = await supabase.from('services').insert({ name, slug, category_id, base_price: 0, is_quote_only: true, is_active: false });
    if (error) alert(error.message); else load();
  };
  return (<>
    <div className="mb-4 flex items-center justify-between"><h1 className="text-2xl font-extrabold">Services</h1><button className="btn" onClick={add}>+ New service</button></div>
    <select className="inp mb-3" value={filter} onChange={(e) => setFilter(e.target.value)}><option value="">All categories</option>{cats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}</select>
    {err && <p className="text-red-700">{err}</p>}
    <div className="card overflow-x-auto"><table className="w-full"><thead><tr><th>Image</th><th>Service</th><th>Category</th><th>Price (₹)</th><th>Mins</th><th>Popular</th><th>Active</th></tr></thead><tbody>
      {rows.filter((r) => !filter || r.category_id === filter).map((s) => (<tr key={s.id}>
        <td>{s.image_url ? <img src={s.image_url} alt="" className="h-12 w-12 rounded object-contain bg-mist" /> : <span className="text-slate2">none</span>}<input type="file" accept="image/*" className="mt-1 block w-28 text-xs" onChange={(e) => upload(s, e.target.files?.[0])} /></td>
        <td><input className="inp w-56" defaultValue={s.name} onBlur={(e) => e.target.value !== s.name && patch(s.id, { name: e.target.value })} /><textarea className="inp mt-1 w-56 text-xs" rows={2} defaultValue={s.description ?? ''} onBlur={(e) => e.target.value !== (s.description ?? '') && patch(s.id, { description: e.target.value })} /></td>
        <td>{s.service_categories?.name}</td>
        <td><input type="number" className="inp w-24" defaultValue={s.base_price} onBlur={(e) => Number(e.target.value) !== Number(s.base_price) && patch(s.id, { base_price: Number(e.target.value), is_quote_only: Number(e.target.value) === 0 })} /><div className="text-xs text-slate2">{s.is_quote_only ? 'quote' : inr(s.base_price)}</div></td>
        <td><input type="number" className="inp w-20" defaultValue={s.duration_minutes} onBlur={(e) => Number(e.target.value) !== s.duration_minutes && patch(s.id, { duration_minutes: Number(e.target.value) })} /></td>
        <td><input type="checkbox" checked={s.is_popular} onChange={(e) => patch(s.id, { is_popular: e.target.checked })} /></td>
        <td><input type="checkbox" checked={s.is_active} onChange={(e) => patch(s.id, { is_active: e.target.checked })} /></td>
      </tr>))}
    </tbody></table></div>
  </>);
}
