import AuthGate from '../AuthGate';
export default function DashLayout({ children }: { children: React.ReactNode }) { return <AuthGate>{children}</AuthGate>; }
