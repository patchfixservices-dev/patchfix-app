'use client';
import { useCallback, useEffect, useState } from 'react';
import { inr, supabase } from '@/lib/supabase';

export default function Overview() {
  const [from, setFrom] = useState(() => new Date(Date.now() - 30 * 864e5).toISOString().slice(0, 10));
  const [to, setTo] = useState(() => new Date().toISOString().slice(0, 10));
  const [rows, setRows] = useState<any[]>([]); const [customers, setCustomers] = useState(0); const [err, setErr] = useState('');
  const load = useCallback(async () => {
    setErr('');
    const { data, error } = await supabase.from('bookings').select('status,total,payment_method,payment_status,scheduled_date,user_id').gte('created_at', from).lte('created_at', to + 'T23:59:59');
    if (error) return setErr(error.message);
    setRows(data ?? []); setCustomers(new Set((data ?? []).map((r) => r.user_id)).size);
  }, [from, to]);
  useEffect(() => { load(); }, [load]);
  const today = new Date().toISOString().slice(0, 10);
  const sum = (f: (r: any) => boolean) => rows.filter(f).reduce((a, r) => a + Number(r.total), 0);
  const cards: [string, string | number][] = [
    ['Total bookings', rows.length], ["Today's bookings", rows.filter((r) => r.scheduled_date === today).length],
    ['Pending (received/confirmed)', rows.filter((r) => ['received', 'confirmed'].includes(r.status)).length],
    ['Completed', rows.filter((r) => r.status === 'completed').length], ['Cancelled', rows.filter((r) => r.status === 'cancelled').length],
    ['Gross booking value (excl. cancelled)', inr(sum((r) => r.status !== 'cancelled'))],
    ['Online payments collected', inr(sum((r) => r.payment_status === 'paid'))],
    ['Cash collected', inr(sum((r) => r.payment_status === 'cash_collected'))],
    ['Cash pending', inr(sum((r) => r.payment_status === 'cash_pending' && r.status !== 'cancelled'))],
    ['Refunded', inr(sum((r) => r.payment_status === 'refunded'))], ['Active customers', customers],
  ];
  return (<>
    <h1 className="mb-4 text-2xl font-extrabold">Overview</h1>
    <div className="mb-4 flex flex-wrap items-center gap-2"><input type="date" className="inp" value={from} onChange={(e) => setFrom(e.target.value)} /><span>to</span><input type="date" className="inp" value={to} onChange={(e) => setTo(e.target.value)} /></div>
    {err && <p className="text-red-700">{err}</p>}
    <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">{cards.map(([l, v]) => <div key={l} className="card"><p className="text-xs text-slate2">{l}</p><p className="text-2xl font-extrabold">{v}</p></div>)}</div>
  </>);
}
