'use client';
import { useCallback, useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

export default function Coupons() {
  const [rows, setRows] = useState<any[]>([]); const [err, setErr] = useState('');
  const [f, setF] = useState({ code: '', discount_type: 'percent', discount_value: '10', min_amount: '0', expires_at: '', usage_limit: '' });
  const load = useCallback(async () => { const { data, error } = await supabase.from('coupons').select('*').order('code'); error ? setErr(error.message) : setRows(data ?? []); }, []);
  useEffect(() => { load(); }, [load]);
  const create = async () => {
    const { error } = await supabase.from('coupons').insert({ code: f.code.trim().toUpperCase(), discount_type: f.discount_type, discount_value: Number(f.discount_value), min_amount: Number(f.min_amount || 0), expires_at: f.expires_at || null, usage_limit: f.usage_limit ? Number(f.usage_limit) : null });
    if (error) alert(error.message); else { setF({ ...f, code: '' }); load(); }
  };
  return (<>
    <h1 className="mb-4 text-2xl font-extrabold">Coupons</h1>{err && <p className="text-red-700">{err}</p>}
    <div className="card mb-4 flex flex-wrap gap-2">
      <input className="inp" placeholder="CODE" value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} />
      <select className="inp" value={f.discount_type} onChange={(e) => setF({ ...f, discount_type: e.target.value })}><option value="percent">Percent</option><option value="fixed">Fixed ₹</option></select>
      <input className="inp w-24" type="number" placeholder="Value" value={f.discount_value} onChange={(e) => setF({ ...f, discount_value: e.target.value })} />
      <input className="inp w-28" type="number" placeholder="Min amount" value={f.min_amount} onChange={(e) => setF({ ...f, min_amount: e.target.value })} />
      <input className="inp" type="date" value={f.expires_at} onChange={(e) => setF({ ...f, expires_at: e.target.value })} />
      <input className="inp w-28" type="number" placeholder="Usage limit" value={f.usage_limit} onChange={(e) => setF({ ...f, usage_limit: e.target.value })} />
      <button className="btn" disabled={!f.code} onClick={create}>Create</button></div>
    <div className="card overflow-x-auto"><table className="w-full"><thead><tr><th>Code</th><th>Discount</th><th>Min</th><th>Expires</th><th>Used</th><th>Active</th></tr></thead><tbody>
      {rows.map((c) => <tr key={c.id}><td className="font-semibold">{c.code}</td><td>{c.discount_type === 'percent' ? `${c.discount_value}%` : `₹${c.discount_value}`}</td><td>₹{c.min_amount}</td><td>{c.expires_at?.slice(0, 10) ?? '—'}</td><td>{c.used_count}{c.usage_limit ? `/${c.usage_limit}` : ''}</td>
        <td><input type="checkbox" checked={c.is_active} onChange={async (e) => { await supabase.from('coupons').update({ is_active: e.target.checked }).eq('id', c.id); load(); }} /></td></tr>)}
    </tbody></table></div>
  </>);
}
