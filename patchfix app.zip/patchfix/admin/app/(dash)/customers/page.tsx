'use client';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

export default function Customers() {
  const [rows, setRows] = useState<any[]>([]); const [err, setErr] = useState('');
  const load = () => supabase.from('profiles').select('*').order('created_at', { ascending: false }).limit(500).then(({ data, error }) => error ? setErr(error.message) : setRows(data ?? []));
  useEffect(() => { load(); }, []);
  return (<>
    <h1 className="mb-4 text-2xl font-extrabold">Customers</h1>{err && <p className="text-red-700">{err}</p>}
    <div className="card overflow-x-auto"><table className="w-full"><thead><tr><th>Name</th><th>Phone</th><th>Email</th><th>Joined</th><th>Account</th></tr></thead><tbody>
      {rows.map((p) => <tr key={p.id}><td>{p.full_name ?? '—'}</td><td>{p.phone}</td><td>{p.email ?? '—'}</td><td>{new Date(p.created_at).toLocaleDateString('en-IN')}</td>
        <td><button className="btn-o" onClick={async () => { const { error } = await supabase.rpc('set_customer_active', { p_id: p.id, p_active: !p.is_active }); if (error) alert(error.message); load(); }}>{p.is_active ? 'Active — suspend' : 'Suspended — restore'}</button></td></tr>)}
    </tbody></table></div>
  </>);
}
