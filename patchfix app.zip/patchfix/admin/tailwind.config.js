module.exports = {
  content: ['./app/**/*.{ts,tsx}', './lib/**/*.{ts,tsx}'],
  theme: { extend: { colors: { charcoal: '#34383D', gold: '#FDBD00', mist: '#F7F8FA', slate2: '#777777' } } },
  plugins: [],
};
